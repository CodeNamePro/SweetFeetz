var canvas = document.querySelector("canvas"); //Create canvas 
canvas.width = 1000; //set canvas width
canvas.height = 640; // set canvas height
var surface = canvas.getContext("2d");

//map image
var map = {img:null, x:0, y:0, width:2000, height:canvas.height, xvel:0, yvel:0, oldX: 0, oldY: 0};
//old map position
var oldMPos; 

//Player
var player = {img:null, x:200, y:canvas.height-132, jumping:false, xvel:0, yvel:0, onGround: false, width:64, height:64, oldX:0, oldY:0};
var bar ={img:null, x:150, y:canvas.height-50, width:0, height:20};
var barHUD = {img:null, x:bar.x-2, y:bar.y-2, width:254, height:24}
//Objects for Bullets, Enemy, Boss, created here so you can call the picture
var bullet ={img:null}
var enemy = {img:null, x:1536 , y: 384, width:32, height:64, ctr: 0, limit: 32, origX: 1536, origY: 384, alive: true}
var boss = {img:null, x:-2000 , y: -2000, width:128, height:256, ctr: 0, limit: 32, origX: 1536, origY: 310,alive: true, health: 5}
//Intervals
var uInt;
var sInt;
sInt = setInterval(startGame, 33.34);

//buttons and title objects
var title = {img:null, x:200, y:50, width:585, height:201}
var startButton = {img:null, x:400, y:300, width: 200, height:50}
var levelButton = {img:null, x:400, y:400, width: 200, height:50}
//button Counter - holds position of what button is selected
var bCtr = 0; 
//pause function
var paused = false;
/*Initialize images
* map = 0, player = 1, bar = 2,
* barHud = 3, Sky = 4, Grass = 5
* startButton = 6, startButtonH = 7 (highlighted)
* levelButton = 8, levelButtonH = 9 (highlighted)
* title = 10 bullet = 11 tiles = 12
*/
var images = [];
var imgStr = ["map", "player","bar", "barHUD", "Sky", "Grass","startButton", "startButtonH", "levelButton", "levelButtonH", "title", "bullet", "tiles", "enemies", "boss"];
for(var v = 0; v < imgStr.length; v++){
	images[v] = new Image();
	images[v].src = imgStr[v] + ".png";
}
map.img = images[0]
player.img = images[1]
bar.img = images[2]
barHUD.img = images[3]
startButton.img = images[6];
levelButton.img = images[8];
title.img = images[10];
bullet.img = images[11];
enemy.img = images[13];
boss.img = images[13]
//spawnEnemies();

function startGame(event){	

	surface.clearRect(0,0,canvas.width,canvas.height);
	surface.drawImage(startButton.img, startButton.x, startButton.y, startButton.width, startButton.height);
	surface.drawImage(levelButton.img, levelButton.x, levelButton.y, levelButton.width, levelButton.height);
	surface.drawImage(title.img, title.x, title.y, title.width, title.height);
	switch (bCtr >= 0 )
	{
		case (bCtr == 0): 	//highlights start button
			startButton.img = images[7];
			bCtr = 1;
			//makes sure if player first presses down it doesnt skip to next button
			downPressed = false;
			break;
		//down pressed goes to level button and highlights it by changing image
		case(downPressed && bCtr == 1):
			startButton.img = images[6];
			levelButton.img = images[9];
			bCtr = 2;
			break;
		//highlights start button if you press up and its on the level button
		case(upPressed && bCtr == 2):
			startButton.img = images[7];
			levelButton.img = images[8];
			bCtr = 1;
			break;
		//starts Game if enter is pressed and start game is selected
		case(enterPressed && startButton.img == images[7]):
			startHit();
			break;
	}
}

//Initialize timer and photos
function startHit(){
	
	clearInterval(sInt);
	for(var q = 0; q < 2; q++){
		
		for ( var j = 0; j< (mapArray[level].length); j++)
		{
			for ( var i = 0; i< (mapArray[level][0].length); i++)
			{
			
				var tile = {}; 	
				tile.img = images[12]
				tile.x = i*32;  
				tile.y = j*32; 
				switch(tile.x == i*32){
					case (mapArray[q][j][i] == 0):
						//AIR
						tile.type = 0;
						break;
					case(mapArray[q][j][i] == 1):
						//PLATFORM
						tile.type = 1;
						break;
					case(mapArray[q][j][i] == 2):
						//JUMP THROUGH BOT
						tile.type = 2;
						break;
					case(mapArray[q][j][i] == 3):
						//BREAKABLE BLOCK
						tile.type = 3;
						break;
					case(mapArray[q][j][i] == 4):
						//BUTTON BLOCK
						tile.type = 4;
						break;
					case(mapArray[q][j][i] == 5):
						//LEVEL UP
						tile.type = 5;
						break;
					case(mapArray[q][j][i] == 6):
						//NEXT LEVEL
						tile.type = 6;
						break;
					case(mapArray[q][j][i] == 7):
						//ENEMY1
						enemy.type = 1
						enemy.origX = tile.x;
						enemy.origY = tile.y;
						tile.type = 0;
						break;
					case(mapArray[q][j][i] == 8):
						//ENEMY2
						enemy.type = 2
						enemy.origX = tile.x;
						enemy.origY = tile.y;
						tile.type = 0;
						break;
					case(mapArray[q][j][i] == 9):
						//BOSS
						boss.origX = tile.x;
						boss.origY = tile.y;
						tile.type = 0;
						break;
				}	
				mapArray[q][j][i] = tile; 
				
			}
		}
	}
	
	uInt = setInterval(update, 33.34);
}


function update()
{
	console.log(mapArray[level][0].length);
	if (paused)
	{
		return;
	}
	bulletCollision();
	if(level == 0){
	moveEnemy();
	enemyCollision();
	}
	if(level == 1){
		bossCollision();
	}
	movePlayer();
	boundries();
	checkCollision();
	movebullets();
	fillMeter();
	animatePlayer();
	render(); 
	
}

//movement variables
var leftPressed = rightPressed = upPressed = spacePressed = downPressed = enterPressed = false;
var inAir = true;
//check if keys are pressed or released
window.addEventListener("keydown", onKeyDown);
window.addEventListener("keyup", onKeyUp);

var pSpeed = 15; //players speed

function movePlayer()
{
//left
	if(player.yvel == 0){
		player.onGround = true
	}
	if (leftPressed == 1 && boundL == false && leftCollision == false) 
	{
		player.xvel -= 1.5; 
		map.xvel = 0;
	}
	else if (leftPressed == 1 && boundL == true && leftCollision == false) 
	{
		if(player.xvel != 0)
                map.xvel = -1 * player.xvel;
		map.xvel += 1.5;
		player.xvel = 0;
	}
	//right  
	if (rightPressed == 1 && boundR == false && rightCollision == false)
    {
		player.xvel += 1.5; 
		map.xvel = 0;
	}
	else if (rightPressed == 1 && boundR == true && rightCollision == false) 
	{
		if(player.xvel != 0)
                map.xvel = -1 * player.xvel;
		map.xvel -= 1.5;
		player.xvel = 0;
	}
	
	//top
	if(player.y < 200)
	{
		map.yvel += 1.5
	}
	/*else if(mapArray[level][0][0].y >= 0){
		map.yvel = 0;
		
	}*/
	if(player.y > 400 && mapArray[level][(mapArray[level].length-1)][0].y >= canvas.height)
	{
		map.yvel -= 2.5
	}
	else if(player.y > 400 && mapArray[level][(mapArray[level].length-1)][0].y < canvas.height){
		map.yvel = 0
	}
    if (spacePressed == 1 && boundT == false && jump == true && inAir == false)
	{
		
		//level = 1;
		player.yvel -= 35;
		map.yvel = 0;
		jump = false
		inAir = true
	}
	
	
	//bottom
	if (upPressed == 1 && TP == true && bar.width > 100)
    {
        if (rightPressed == true)
        {
            tele = true;
            player.x += 300;
            TP = false
        }
        else if (leftPressed == true)
        {
            tele = true;
            player.x -= 300;
            TP = false
        }
    bar.width -= 100;
    }
    else
    {
        tele = false;
    }
	
	//movement physics
	player.oldX = player.x;
	player.x += player.xvel;
	
	player.oldY= player.y;
	player.y += player.yvel;
	
	map.oldX = map.x
	map.x += map.xvel
	for ( var i = 0; i< (mapArray[level][0].length); i++)
	{
		for ( var j = 0; j< (mapArray[level].length); j++)
		{
			mapArray[level][j][i].x += map.xvel
			mapArray[level][j][i].y += map.yvel
		}
	}
	enemy.x += map.xvel 
	enemy.y += map.yvel 
	boss.x += map.xvel 
	boss.y += map.yvel 
	player.xvel *= 0.8;
	map.xvel *= 0.9;
	map.yvel *= 0.9;
	player.yvel *= 0.9;
	
	
	
	if(player.xvel < 0.1 && player.xvel > -0.1){
		player.xvel = 0;
	}
	if(player.yvel < 0.1 && player.yvel > -0.1){
		player.yvel = 0;
	}
	
	rightCollision = leftCollision = topCollision = bottomCollision = false;
}

//Players current sprite
var playerSprite = 0; 
//counts frames until next animation
var spriteCtr = 0;
// holds direction player is facing
var LorR = 0;
//last left sprite (left sprites are from 8-5)
var leftSprite = 5;
//last sprite for right direction (right sprites are 0-4)
var rightSprite = 4;
//frames that have to pass to change animation
var framesPerSprite = 4;
function animatePlayer()
{
	//Faces direction last pressed
	if(playerSprite != 0 && LorR == 2 && !rightPressed)
		playerSprite = 0;
	if(playerSprite != 7 && LorR == 1 && !leftPressed)
		playerSprite = 7
	//Animation
	if((rightPressed || leftPressed) && player.x > 0){
		spriteCtr++;
		//Right animation
		if(spriteCtr == framesPerSprite && rightPressed){
			LorR = 2;
			spriteCtr = 0;
			playerSprite++;
			if (playerSprite >= rightSprite)
				playerSprite = 0;
		}
		//Left animation
		if(spriteCtr == framesPerSprite && leftPressed){
			LorR = 1;
			spriteCtr = 0;
			playerSprite--;
			if (playerSprite <= leftSprite)
				playerSprite = 7;
		}
	}
	


}
var shootLeft = false;
var shootUp = shootDown = false;
function onKeyDown(event)
{
	switch (event.keyCode)
	{
		case 37: //left arrow
			leftPressed = true;
			break;
		case 39: //right arrow
			rightPressed = true;
			break;
		case 38: //up arrow
			if (upPressed == false)
            {
            upPressed = true;
            TP = true;
            }
            break;
		case 32: // spacebar
			if (spacePressed == false)
            {
            spacePressed = true;
			jump = true;
            }
			break;
		case 40:
			downPressed = true;
			break;
		case 13:
			enterPressed = true;
			break; 
		case 81: // Q
			if(bar.width > 25){
				enterPressed = true;
				spawnBullet();
				bar.width -= 25
			}
			break;
		case 80://p
			paused = !paused
			break;
		case 65://a
			if(bar.width > 25){
				shootLeft = true;
				enterPressed = true;
				bar.width -= 25
				spawnBullet();
			}
			break;
		case 68:// d
			if(bar.width > 25){
				enterPressed = true;
				bar.width -= 25
				shootLeft = false;
				spawnBullet()
			}
			break;
			case 87://w
				shootUp = true;
			break;
			case 83://s
				shootDown = true;
			
			break;
	} 
}

function onKeyUp(event)
{
	switch (event.keyCode)
	{
		case 37: //left arrow
			leftPressed = false;
			break;
		case 39: //right arrow
			rightPressed = false;
			break;
		case 38:// up arrow
			upPressed = false;
			break;
		case 32: //spacebar
			spacePressed = false;
			break;
		case 40:
			downPressed = false;
			break;
		case 13:
			enterPressed = false;
			break;
			case 87://w
				shootUp = false;
			break;
			case 83://s
				shootDown = false;
			
			break;
	}
}
//Meter
var mtrFill = 1;
var oldBW;
var mtrEtr = 50;
function fillMeter()
{

	if ((player.xvel >= 3 || player.xvel <= -3)||((map.xvel <= -3  && rightPressed == true)||( map.xvel >= 3 && leftPressed == true)))
	{
		if(bar.width <= 250){
			bar.width += mtrFill;
		}
	}
	else
	{
		if(bar.width != 0)
		bar.width -= mtrFill;
	}
	oldBW = bar.width
}
	
function render()
{
	surface.clearRect(0,0,canvas.width,canvas.height);
	
	//surface.drawImage(map.img, map.x, map.y, map.width, map.height);
	for ( var i = 0; i < (mapArray[level][0].length); i++)
	{
		for ( var j = 0; j < (mapArray[level].length); j++)
		{
			surface.drawImage(mapArray[level][j][i].img, 32*mapArray[level][j][i].type, 0,32 ,32,mapArray[level][j][i].x, mapArray[level][j][i].y, 34,32);
		
		}
	}
	
	surface.drawImage(bar.img, bar.x, bar.y, bar.width, bar.height);
	surface.drawImage(barHUD.img, barHUD.x, barHUD.y, barHUD.width, barHUD.height);
	if (tele == false)
    {
    surface.drawImage(player.img,64*playerSprite, 0, 64, 64,player.x, player.y, 64, 64);
    }
	if(enemy.alive && level == 0){
	surface.drawImage(enemy.img, 32, 0, 32, 64,enemy.x, enemy.y, 32, 64);
	}
	if(boss.alive && level == 1){
	surface.drawImage(boss.img, 0, 0, 32, 64,boss.x, boss.y, boss.width, boss.height);
	}
	if(level == 1){
		surface.drawImage(bar.img, bar.x,  bar.y - 500, boss.health * 50, bar.height);
		surface.drawImage(barHUD.img, barHUD.x, barHUD.y - 500, barHUD.width, barHUD.height);
		
	}
	for (var i = 0; i < bulletArray.length; i++)
	{
		surface.beginPath();
		surface.arc(bulletArray[i].x,bulletArray[i].y,4, 0, 2*Math.PI);
		surface.fillStyle = "white";
		surface.fill();
		surface.lineWidth = 2;
		surface.strokeStyle = "red";
		surface.stroke();
		surface.closePath();
	}
	surface.font = "20px Georgia";
	surface.fillText("Lives: " + lives.toString(), 850, 50);
}	
var leftCollision, rightCollision, topCollision, bottomCollision = false;
var rowCollided = 0;
var colCollided = 0;
function changeLevel(){
	if(level == 0){
		level = 1;
		mapArray.x = player.xvel = player.yvel = map.x = 0;
		player.x = 200;
		player.y = canvas.height-132;
		boss.x = boss.origX
		boss.y = boss.origY
	}
}
function death(){
	lives --;
	if(lives > 0){
		mapArray.x = player.xvel = player.yvel = map.x = 0;
		for ( var j = 0; j< (mapArray[level].length); j++)
		{
			for ( var i = 0; i< (mapArray[level][0].length); i++)
			{
				mapArray[level][j][i].x = i*32;  
				mapArray[level][j][i].y = j*32; 
			}
		}
		if(level == 0){
		enemy.x = enemy.origX
		enemy.y = enemy.origY
		enemy.ctr = 0;
		enemy.alive = true;
		enemyHit = false;
		hitRight = false
		}
		if(level == 1){
			boss.x = boss.origX
			boss.y = boss.origY
			boss.health = 5;
			
		}
		bar.width = 0;
		player.x = 200;
		player.y = canvas.height-132;
	}
	else{
		console.log("game over")
	}
}
var lives = 3;
function checkCollision()
{
	for ( var i = 0; i< (mapArray[level][0].length); i++)
	{
		for ( var j = 0; j< (mapArray[level].length) ; j++)
		{
			//EFFECTS PLAYER DEPENDING ON WHAT COLLISION HIT
			if(topCollision){
				if(mapArray[level][rowCollided][colCollided].type == 6){
					changeLevel();
					topCollision = false 
					continue
				}
				player.y = mapArray[level][rowCollided][colCollided].y + 32
				player.yvel = 0;
					
				if(mapArray[level][rowCollided][colCollided].type == 7){
					pickup ++;
					mapArray[level][rowCollided][colCollided].type = 0
				}
				topCollision = false
				
				
			}
			if(bottomCollision){
				if(mapArray[level][rowCollided][colCollided].type == 6){
					changeLevel();
				}
				//if(!mapArray[level][rowCollided][colCollided].type == 6 && !mapArray[level][rowCollided][colCollided].type == 7){
					player.y = mapArray[level][rowCollided][colCollided].y - player.height
					player.onGround = true;
					if(player.yvel > 0){
						player.yvel = 0;
					}
					inAir = false;
				//}
				if(mapArray[level][rowCollided][colCollided].type == 7){
					pickup ++;
					mapArray[level][rowCollided][colCollided].type = 0
				}
				bottomCollision = false;
			}
			else if(!bottomCollision)
			{
				player.onGround = false;
			}
			if(leftCollision){
				if(mapArray[level][rowCollided][colCollided].type == 6){
					changeLevel();
				}
				//if(!mapArray[level][rowCollided][colCollided].type == 6 && !mapArray[level][rowCollided][colCollided].type == 7){
					player.x = mapArray[level][rowCollided][colCollided].x + 33;
					player.xvel = 0;
				//}
				if(mapArray[level][rowCollided][colCollided].type == 7){
					pickup ++;
					mapArray[level][rowCollided][colCollided].type = 0
				}
				leftCollision = false;
			}
			if(rightCollision){
				if(mapArray[level][rowCollided][colCollided].type == 6){
					changeLevel();
					rightCollision = false 
					continue
				}
				//if(!mapArray[level][rowCollided][colCollided].type == 6 && !mapArray[level][rowCollided][colCollided].type == 7){
					player.x = mapArray[level][rowCollided][colCollided].x - player.width - 1;
					xvel = 0;
			//	}
				if(mapArray[level][rowCollided][colCollided].type == 7){
					pickup ++;
					mapArray[level][rowCollided][colCollided].type = 0
				}
				rightCollision = false;
			}
			//CHECKS COLLISION
			//top
			 if(player.x + 4 < mapArray[level][j][i].x + 32 && player.x + player.width - 4 > mapArray[level][j][i].x){
                if(player.y < mapArray[level][j][i].y + 32 && player.y + 10 > mapArray[level][j][i].y + 12){
					//any block you cant go through 
					if(mapArray[level][j][i].type == 1 ){
						rowCollided = j;
						colCollided = i;
						topCollision = true
						continue
					}
				}
			}
			//bottom
			if(player.x + 4 < mapArray[level][j][i].x + 32 && player.x + player.width - 4 > mapArray[level][j][i].x){
                if((player.y + player.height > mapArray[level][j][i].y) && player.y + player.height - 15 < mapArray[level][j][i].y + 20){
					//any block you cant go through 
					if(mapArray[level][j][i].type == 1 || mapArray[level][j][i].type == 2){
						rowCollided = j;
						colCollided = i;
						bottomCollision = true
						continue
					}
					
					
				}
			}
			if(player.y + 4 < mapArray[level][j][i].y + 32 && player.y + player.height - 4 > mapArray[level][j][i].y){
                if(player.x + player.width > mapArray[level][j][i].x && player.x + player.width - 10 < mapArray[level][j][i].x + 20 ){
					//any block you cant go through 
					if(mapArray[level][j][i].type == 1 ){
						rowCollided = j;
						colCollided = i;
						rightCollision = true
						continue
					}
				}
			}
			if(player.y + 4 < mapArray[level][j][i].y + 32 && player.y + player.height - 4 > mapArray[level][j][i].y){
                if(player.x + 10 > mapArray[level][j][i].x + 12 && player.x < mapArray[level][j][i].x + 32){
					//any block you cant go through 
					if(mapArray[level][j][i].type == 1 ){
						rowCollided = j;
						colCollided = i;
						leftCollision = true;
						continue
					}
				}
			}
			
			
		}
		
		
	}
	if(player.onGround == false){
		player.yvel += 3;
	}
}