var canvas = document.querySelector("canvas"); //Create canvas 
canvas.width = 1000; //set canvas width
canvas.height = 640; // set canvas height
var surface = canvas.getContext("2d");

//movement variables
var leftPressed, rightPressed, upPressed, spacePressed, downPressed, enterPressed = false;
//check if keys are pressed or released
window.addEventListener("keydown", onKeyDown);
window.addEventListener("keyup", onKeyUp);

var pSpeed = 15; //players speed
var oldMPos; //old map position
//images
var images = [];
var imgStr = ["map", "platf", "smplat", "player","bar", "barHUD", "Sky", "Grass"];
var smPlat = images[2]
var map = {img:null, x:0, y:0, width:2000, height:canvas.height, xvel:0, yvel:0};
var player = {img:null, x:200, y:canvas.height-132, jumping:false, xvel:0, yvel:0, onGround: false};
var playerSprite = 0; 
var spriteCtr = 0;
var framesPerSprite = 4;
var lgPlat = {img:null, x:-150, y:canvas.height-64, width:2000, height:60};
var bar ={img:null, x:150, y:canvas.height-50, width:0, height:20};
var barHUD = {img:null, x:bar.x-2, y:bar.y-2, width:254, height:24}
var uInt;
var LorR = 0;
var leftSprite = 5;
var rightSprite = 4;
//map variable
// 20 rows and 125 cols
var mapArray = [
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,0,0,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
	[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
] 

var sInt;
sInt = setInterval(startGame, 33.34);
//startGame();
var startButton = {img:null, x:400, y:300, width: 200, height:50}
var levelButton = {img:null, x:400, y:400, width: 200, height:50}
var buttonArray = ["startButton", "startButtonH", "levelButton", "levelButtonH"];
var bCtr = 0; //button Counter
for(var v = 0; v < buttonArray.length; v++){
	images[v + 300] = new Image();
	images[v + 300].src = buttonArray[v] + ".png";
}
startButton.img = images[300];
levelButton.img = images[302];
function startGame(){
	

	surface.clearRect(0,0,canvas.width,canvas.height);
	surface.drawImage(startButton.img, startButton.x, startButton.y, startButton.width, startButton.height);
	surface.drawImage(levelButton.img, levelButton.x, levelButton.y, levelButton.width, levelButton.height);
	if((downPressed || upPressed || spacePressed || rightPressed || leftPressed) && bCtr == 0){
		startButton.img = images[301];
		levelButton.img = images[302];
		bCtr = 1;
		downPressed = false;
	}
	else if(downPressed && bCtr == 1){
		startButton.img = images[300];
		levelButton.img = images[303];
		bCtr = 2;
	}
	else if(upPressed && bCtr == 2){
		startButton.img = images[301];
		levelButton.img = images[302];
		bCtr = 1;
	}
	
	if(enterPressed && startButton.img == images[301]){
		startHit();
	}

	

}

//Initialize timer and photos
function startHit(){
	clearInterval(sInt);
	for (var i = 0; i < imgStr.length; i++)
	{
		images[i] = new Image();
		images[i].src = imgStr[i]+".png";
	}
	for ( var j = 0; j< 20; j++)
	{
		for ( var i = 0; i< 125; i++)
		{
			var tile = {}; 	
			tile.x = i*32;  
			tile.y = j*32; 
			if (mapArray[j][i] == 1)
			{
				tile.img = images[imgStr.length - 1];
				tile.plat = true;
			}
			else 
			{
				tile.img = images[imgStr.length - 2];
				tile.plat = false;
			}
			mapArray[j][i] = tile; 
			}
	}
	map.img = images[0]
	player.img = images[3]
	lgPlat.img = images[1]
	bar.img = images[4]
	barHUD.img = images[5]
	uInt = setInterval(update, 33.34);
}
//Meter

//FIX METER DROPPING UNDER 0 WIDTH ON JUMP
var mtrFill = 2;
var oldBW;
var mtrEtr = 50;

function update()
{
	movePlayer();
	fillMeter();
	checkCollision();
	animatePlayer();
	render(); 
	//console.log()
}

function movePlayer()
{
	//Enterance to screen
	if (player.x <= -10)
		player.x += pSpeed;
	
	if (player.jumping == true)
	{
		spacePressed = false;
		player.jumping = false;
	}
		
	//Left movement
	
	if (leftPressed == true && player.x >= 0){
			player.xvel -= 1.5;
			map.xvel = 0;
	}	
	else if (leftPressed == true || player.x <= 0){
		player.xvel = 0;
	}
	
	
	
	//right movement
	if (rightPressed == true && player.x <= 200)
	{
			player.xvel += 1.5;	
	}
	else if(rightPressed == true &&(map.x + map.width) != 640)//need to combo move physics with map.x
	{
		map.xvel = player.xvel;
		player.xvel = 0;
		map.xvel -= 10
				
	}
	

	
	if (spacePressed == true && bar.width >= 50) 
	{
	player.jumping = true;
	player.yvel -= 40;
	bar.width = oldBW - mtrEtr;
	}
	
	//movement physics
	player.x += player.xvel;
	player.y += player.yvel;
	map.x += map.xvel
	for ( var i = 0; i< 125; i++)
	{
		for ( var j = 0; j< 20; j++)
		{
			mapArray[j][i].x += map.xvel
		}
	}
	player.xvel *= 0.8;
	map.xvel *= 0.9
	player.yvel *= 0.9;

}
function moveMap(){
	
}
function animatePlayer()
{
//Faces direction last pressed
if(playerSprite != 0 && LorR == 2 && !rightPressed)
	playerSprite = 0;
if(playerSprite != 7 && LorR == 1 && !leftPressed)
	playerSprite = 7
//Animation
if((rightPressed || leftPressed) && player.x > 0)
{	
	spriteCtr++;
	//Right animation
	if (spriteCtr == framesPerSprite && rightPressed)
	{
		LorR = 2;
		spriteCtr = 0;
		playerSprite++;
		if (playerSprite >= rightSprite)
			playerSprite = 0;
	}
	//Left Animation
	if (spriteCtr == framesPerSprite && leftPressed)
	{
		LorR = 1;
		spriteCtr = 0;
		playerSprite--;
		if (playerSprite <= leftSprite)
			playerSprite = 7;
	}
}

}
function onKeyDown(event)
{
	switch (event.keyCode)
	{
		case 37: //left arrow
			leftPressed = true;
			break;
		case 39: //right arrow
			rightPressed = true;
			break;
		case 38: //up arrow
			upPressed = true;
			break;
		case 32: // spacebar
			spacePressed = true;
			break;
		case 40:
			downPressed = true;
			break;
		case 13:
			enterPressed = true;
			break; 
	} 
}

function onKeyUp(event)
{
	switch (event.keyCode)
	{
		case 37: //left arrow
			leftPressed = false;
			break;
		case 39: //right arrow
			rightPressed = false;
			break;
		case 38:// up arrow
			upPressed = false;
			break;
		case 32: //spacebar
			spacePressed = false;
			break;
		case 40:
			downPressed = false;
			break;
		case 13:
			enterPressed = false;
			break;
	}
}

function fillMeter()
{

			if ((player.xvel >= 1.5 || player.xvel <= -1.5)||(map.xvel <= -5 ))
			{
				if(bar.width <= 250){
					bar.width += mtrFill;
				}
				//oldMPos = map.x;
			}
			else
			{
				if(bar.width != 0)
				bar.width -= mtrFill;
			}
	
oldBW = bar.width
}
	
function render()
{
	surface.clearRect(0,0,canvas.width,canvas.height);
	
	surface.drawImage(map.img, map.x, map.y, map.width, map.height);
	for ( var i = 0; i< 125; i++)
	{
		for ( var j = 0; j< 20; j++)
		{
			surface.drawImage(mapArray[j][i].img, mapArray[j][i].x, mapArray[j][i].y);
			}
	}
	//surface.drawImage(lgPlat.img, lgPlat.x, lgPlat.y, lgPlat.width, lgPlat.height);
	surface.drawImage(bar.img, bar.x, bar.y, bar.width, bar.height);
	surface.drawImage(barHUD.img, barHUD.x, barHUD.y, barHUD.width, barHUD.height);
	surface.drawImage(player.img,64*playerSprite, 0, 64, 64,player.x, player.y, 64, 64);
}
function checkCollision()
{
	if(player.onGround == false){
			player.yvel += 2;
	}
	for ( var i = 0; i< 125; i++)
	{
		for ( var j = 0; j< 20; j++)
		{
			if(player.x < mapArray[j][i].x +32 && player.x+64 > mapArray[j][i].x && player.y < mapArray[j][i].y +32 && player.y +64 > mapArray[j][i].y){
				if(mapArray[j][i].plat == true){
					player.yvel = 0;
					player.onGround = true;
				}
				else if (mapArray[j][i].plat == false){
					player.onGround = false;
				}
			}
		}
		
	}
	

}