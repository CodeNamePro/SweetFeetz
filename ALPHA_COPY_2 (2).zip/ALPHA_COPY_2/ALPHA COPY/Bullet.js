const BULLETSPEED = 15;
const SIZE = 100;
var bulletArray = [];

function spawnBullet()
{
	var bullet = {x:player.x+SIZE/1.5, y:player.y+SIZE/2};
	bulletArray.push(bullet);
	
	
}

function movebullets()
{
	var i = 0;
	while (bulletArray[i] != undefined)
	{
		if (bulletArray[i].x < canvas.width+5)
			bulletArray[i++].x += BULLETSPEED;
		else
			bulletArray.splice(i,1);
	}
}