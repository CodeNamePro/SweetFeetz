var canvas = document.querySelector("canvas"); //Create canvas 
canvas.width = 1000; //set canvas width
canvas.height = 640; // set canvas height
var surface = canvas.getContext("2d");

//map image
var map = {img:null, x:0, y:0, width:2000, height:canvas.height, xvel:0, yvel:0, oldX: 0, oldY: 0};
//old map position
var oldMPos; 


//Player
var player = {img:null, x:200, y:canvas.height-132, jumping:false, xvel:0, yvel:0, onGround: false, width:64, height:64, oldX:0, oldY:0};

var bar ={img:null, x:150, y:canvas.height-50, width:0, height:20};
var barHUD = {img:null, x:bar.x-2, y:bar.y-2, width:254, height:24}
var uInt;

var bullet ={img:null}

var sInt;
sInt = setInterval(startGame, 33.34);
//buttons and title objects
var title = {img:null, x:200, y:50, width:585, height:201}
var startButton = {img:null, x:400, y:300, width: 200, height:50}
var levelButton = {img:null, x:400, y:400, width: 200, height:50}
//button Counter - holds position of what button is selected
var bCtr = 0; 
/*Initialize images
* map = 0, player = 1, bar = 2,
* barHud = 3, Sky = 4, Grass = 5
* startButton = 6, startButtonH = 7 (highlighted)
* levelButton = 8, levelButtonH = 9 (highlighted)
* title = 10
*/


var images = [];
var imgStr = ["map", "player","bar", "barHUD", "Sky", "Grass","startButton", "startButtonH", "levelButton", "levelButtonH", "title","bullet"];
for(var v = 0; v < imgStr.length; v++){
	images[v] = new Image();
	images[v].src = imgStr[v] + ".png";
}
map.img = images[0]
player.img = images[1]
bar.img = images[2]
barHUD.img = images[3]
startButton.img = images[6];
levelButton.img = images[8];
title.img = images[10]
bullet.img = images[11];

function startGame(event){	

	surface.clearRect(0,0,canvas.width,canvas.height);
	surface.drawImage(startButton.img, startButton.x, startButton.y, startButton.width, startButton.height);
	surface.drawImage(levelButton.img, levelButton.x, levelButton.y, levelButton.width, levelButton.height);
	surface.drawImage(title.img, title.x, title.y, title.width, title.height);
	switch (bCtr >= 0 )
	{
		case (bCtr == 0): 	//highlights start button
			startButton.img = images[7];
			bCtr = 1;
			//makes sure if player first presses down it doesnt skip to next button
			downPressed = false;
			break;
		//down pressed goes to level button and highlights it by changing image
		case(downPressed && bCtr == 1):
			startButton.img = images[6];
			levelButton.img = images[9];
			bCtr = 2;
			break;
		//highlights start button if you press up and its on the level button
		case(upPressed && bCtr == 2):
			startButton.img = images[7];
			levelButton.img = images[8];
			bCtr = 1;
			break;
		//starts Game if enter is pressed and start game is selected
		case(enterPressed && startButton.img == images[7]):
			startHit();
			break;
	}
}

//Initialize timer and photos
function startHit(){
	
	clearInterval(sInt);
	for (var i = 0; i < imgStr.length; i++)
	{
		images[i] = new Image();
		images[i].src = imgStr[i]+".png";
	}
	for ( var j = 0; j< 20; j++)
	{
		for ( var i = 0; i< 125; i++)
		{
			var tile = {}; 	
			tile.x = i*32;  
			tile.y = j*32; 
			switch(tile.x == i*32){
				case (mapArray[j][i] == 1):
					//grass
					tile.img = images[5];
					tile.type = 1;
					break;
				case(mapArray[j][i] == 0):
					//sky
					tile.img = images[4];
					tile.type = 0;
					break;
			}	
			mapArray[j][i] = tile; 
			}
	}
	
	uInt = setInterval(update, 33.34);
}


function update()
{
	
	movePlayer();
	boundries();
	movebullets();
	checkCollision();
	fillMeter();
	animatePlayer();
	render(); 
	//console.log(player.x)
	//console.log(map.x);
}

//movement variables
var leftPressed, rightPressed, upPressed, spacePressed, downPressed, enterPressed = false;

//check if keys are pressed or released
window.addEventListener("keydown", onKeyDown);
window.addEventListener("keyup", onKeyUp);

var pSpeed = 15; //players speed

function movePlayer()
{
//left
	if (leftPressed == 1 && boundL == false) 
	{
		player.xvel -= 1.5; 
		map.xvel = 0;
	}
	else if (leftPressed == 1 && boundL == true) 
	{
		if(player.xvel != 0)
                map.xvel = -1 * player.xvel;
		map.xvel += 1.5;
		player.xvel = 0;
	}
//right  
  if (rightPressed == 1 && boundR == false)
     {
		player.xvel += 1.5; 
		map.xvel = 0;
	}
	else if (rightPressed == 1 && boundR == true) 
	{
		if(player.xvel != 0)
                map.xvel = -1 * player.xvel;
		map.xvel -= 1.5;
		player.xvel = 0;
	}
//top	
    if (spacePressed == 1 && boundT == false)
	{
		player.y -= 40;
		map.yvel = 0;
	}
	
	
//bottom
	if (downPressed == 1 && player.colB == false)
        player.y += player.speed;
	
	
	
	
	
	
	//movement physics
	player.oldX = player.x;
	player.x += player.xvel;
	
	player.oldY= player.y;
	player.y += player.yvel;
	
	map.oldX = map.x
	map.x += map.xvel
	for ( var i = 0; i< 125; i++)
	{
		for ( var j = 0; j< 20; j++)
		{
			mapArray[j][i].x += map.xvel
		}
	}
	player.xvel *= 0.8;
	map.xvel *= 0.9
	player.yvel *= 0.9;
	
}

//Players current sprite
var playerSprite = 0; 
//counts frames until next animation
var spriteCtr = 0;
// holds direction player is facing
var LorR = 0;
//last left sprite (left sprites are from 8-5)
var leftSprite = 5;
//last sprite for right direction (right sprites are 0-4)
var rightSprite = 4;
//frames that have to pass to change animation
var framesPerSprite = 4;
function animatePlayer()
{
	//Faces direction last pressed
	if(playerSprite != 0 && LorR == 2 && !rightPressed)
		playerSprite = 0;
	if(playerSprite != 7 && LorR == 1 && !leftPressed)
		playerSprite = 7
	//Animation
	if((rightPressed || leftPressed) && player.x > 0){
		spriteCtr++;
		//Right animation
		if(spriteCtr == framesPerSprite && rightPressed){
			LorR = 2;
			spriteCtr = 0;
			playerSprite++;
			if (playerSprite >= rightSprite)
				playerSprite = 0;
		}
		//Left animation
		if(spriteCtr == framesPerSprite && leftPressed){
			LorR = 1;
			spriteCtr = 0;
			playerSprite--;
			if (playerSprite <= leftSprite)
				playerSprite = 7;
		}
	}
	


}

function onKeyDown(event)
{
	switch (event.keyCode)
	{
		case 37: //left arrow
			leftPressed = true;
			break;
		case 39: //right arrow
			rightPressed = true;
			break;
		case 38: //up arrow
			upPressed = true;
			break;
		case 32: // spacebar
			spacePressed = true;
			break;
		case 40:
			downPressed = true;
			break;
		case 13:
			enterPressed = true;
			break; 
		case 81: // Q
			enterPressed = true;
			spawnBullet();
			break;
	
	} 
}

function onKeyUp(event)
{
	switch (event.keyCode)
	{
		case 37: //left arrow
			leftPressed = false;
			break;
		case 39: //right arrow
			rightPressed = false;
			break;
		case 38:// up arrow
			upPressed = false;
			break;
		case 32: //spacebar
			spacePressed = false;
			break;
		case 40:
			downPressed = false;
			break;
		case 13:
			enterPressed = false;
			break;
		
	
	
	
	}
}	


//Meter
var mtrFill = 1;
var oldBW;
var mtrEtr = 50;
function fillMeter()
{

	if ((player.xvel >= 3 || player.xvel <= -3)||(map.xvel <= -3  && rightPressed))
	{
		if(bar.width <= 250){
			bar.width += mtrFill;
		}
		//oldMPos = map.x;
	}
	else
	{
		if(bar.width != 0)
		bar.width -= mtrFill;
	}
	oldBW = bar.width
}
	
function render()
{
	surface.clearRect(0,0,canvas.width,canvas.height);
	
	surface.drawImage(map.img, map.x, map.y, map.width, map.height);
	for ( var i = 0; i< 125; i++)
	{
		for ( var j = 0; j< 20; j++)
		{
			surface.drawImage(mapArray[j][i].img, mapArray[j][i].x, mapArray[j][i].y);
		}
	}
	
	surface.drawImage(bar.img, bar.x, bar.y, bar.width, bar.height);
	surface.drawImage(barHUD.img, barHUD.x, barHUD.y, barHUD.width, barHUD.height);
	surface.drawImage(player.img,64*playerSprite, 0, 64, 64,player.x, player.y, 64, 64);
	for (var i = 0; i < bulletArray.length; i++)
	{
		surface.beginPath();
		surface.arc(bulletArray[i].x,bulletArray[i].y,4, 0, 2*Math.PI);
		surface.fillStyle = "white";
		surface.fill();
		surface.lineWidth = 2;
		surface.strokeStyle = "red";
		surface.stroke();
		surface.closePath();
	}
}
	var leftCollision, rightCollision, topCollision, bottomCollision = false;
function checkCollision()
{
	for ( var i = 0; i< 125; i++)
	{
		for ( var j = 0; j< 20; j++)
		{
			//console.log(mapArray[j][i].type)
			//check right and left
			if(player.x < mapArray[j][i].x + 32 && player.x + player.width > mapArray[j][i].x){
				//check top and bottom
				if(player.y < mapArray[j][i].y + 32 && player.y + player.height > mapArray[j][i].y){
					if(mapArray[j][i].type == 1){
						//left
						if((player.oldX > player.x || map.oldX > map.x)){
							player.xvel = 0
							map.xvel = 0;
							player.x =  player.oldX;
							map.x = map.oldX
							leftCollision = true;
						}
						//right
						else if (player.oldX < player.x || map.oldX < map.x){
							player.xvel = 0
							map.xvel = 0;
							player.x = player.oldX;
							map.x = map.oldX
							rightCollision = true;
						}
						//down
						if(player.oldY < player.y){
							player.yvel = 0;
							player.y = player.oldY;
							bottomCollision = true;
						}
						//up
						else if(player.oldY > player.y){
							player.yvel = 0;
							player.y = player.oldY;
							topCollision = true;
						}
						
						/**/
					}
				}
			}
			
						
		}
	}
	//if(!player.onGround){
	//	player.yvel += 3
	//}
}
