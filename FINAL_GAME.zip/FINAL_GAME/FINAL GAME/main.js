/*
* To Do:
*- splash screen in and out
*- fix fade in and out functions
*
*/
var canvas = document.querySelector("canvas"); //Create canvas 
canvas.width = 1000; //set canvas width
canvas.height = 640; // set canvas height
var surface = canvas.getContext("2d");

//map object holds map velocity, image and more
var map = {img:null, x:0, y:0, width:null, height:null, xvel:0, yvel:0, oldX: 0, oldY: 0};
var movementSpeed = 2;
//Player
var player = {img:null, x:200, y:canvas.height-132, jumping:false, xvel:0, yvel:0, onGround: false, width:128, height:128, oldX:0, oldY:0};
//Players Bar
var bar ={img:null, x:150, y:canvas.height-50, width:0, height:20};
//Bars HUD
var barHUD = {img:null, x:bar.x-2, y:bar.y-2, width:745, height:24};
//Objects for Bullets created here so you can call the picture
var bullet ={img:null};
//start inverval and update interval
var uInt;
//start uInt timer for title screen
uInt = setInterval(update, 33.34);

//screen state (0 = title, 1 = startscreen, 2 = game);
var screenState = 0;
//buttons and title objects for title screen
var title = {img:null, x:200, y:50, width:585, height:201};
var startButton = {img:null, x:400, y:300, width: 200, height:50};
var levelButton = {img:null, x:400, y:400, width: 200, height:50};
var quitButton = {img:null, x:400, y:500, width: 200, height:50};
var splash = {img:null, x: 0, y: 0 , width: canvas.width, height: canvas.height, ctr: 0, time: 150};
//button Counter - holds position of what button is selected
var bCtr = 0; 
//Paused boolean
var paused = false;

// VARIABLES DECLARE HERE IN ONE SPOT
//Movement variables
var leftPressed = rightPressed = upPressed = spacePressed = downPressed = enterPressed = false;
var aPressed = wPressed = sPressed = dPressed = false;
//Fading variables
var opaq = 1;
var fadeIn = fadeOut = false;
//map level
var level = 0;
//Players current sprite
var playerSprite = 0; 
//counts frames until next animation
var spriteCtr = 0;
// holds direction player is facing
var LorR = 0;
//last left sprite (left sprites are from 8-5)
var leftSprite = 0;
//last sprite for right direction (right sprites are 0-4)
var rightSprite = 7;
//frames that have to pass to change animation
var framesPerSprite = 5;
var enemies = [];
var sNumCtr = 0;
var leftarm = {img:null, x:385, y:350, width:100, height:150}
var bossbot = {img:null, x:400, y:200, width:370, height:316}
var rightarm = {img:null, x:685, y:350, width:100, height:150}
var gameOver = {img:null, x:0, y:0, width:canvas.width, height:canvas.height}
var pauseMenu = {img:null, x:0, y:0, width:canvas.width, height:canvas.height}
var telegraph = {img: null, x:0, y:0, width: 600, height: player.height}
var skull= {img:null, x:0, y:0, width:500, height:539}
var healthHUD = {img:null, x:850, y:70, width:64, height:64}
var TP = false;
var teleDist = 300;
var respawn = false;
var Dup = canvas.height - 300;
var power = 0;
var playFace = 12;
var tpLeft = tpRight = false;
var shieldPickup = false;
var shootingBlockInMap = false;
var jumpPower = 50;
var mapMaxY = 0;
var floorHeight = 715;
var mapOverlay = {img:null, x:0, y:0, width:null, height:null, xvel:0, yvel:0, oldX: 0, oldY: 0};







/*Initialize images
* map = 0, player = 1, bar = 2,
* barHud = 3, startButton = 4, 
*startButtonH = 5 (highlighted) levelButton = 6,
* levelButtonH = 7 (highlighted) title = 8 
* splashScreen = 9 bullet = 10 tiles = 11
* quitButton = 12, quitButtonH = 13
*/
var images = [];
var imgStr = ["map", "player","bar", "barHUD","startButton", "startButtonH", "levelButton", "levelButtonH", "title","splashScreen","bullet", "tiles", "quitButton", "quitButtonH", "ratSmall", "ratLarge", "sign", "leftarm", "rightarm", "bossbot","gameOver","pauseMenu", "bossbot1", "bossbot2", "bossbot3", "bossbot4", "bossbot5", "telegraph", "telegraphx", "skull", "player1", "player2", "health", "player3", "mapOverlay", "tiles1"];
for(var v = 0; v < imgStr.length; v++){
	images[v] = new Image();
	images[v].src = imgStr[v] + ".png";
}
map.img = images[0];
player.img = images[1];
bar.img = images[2];
barHUD.img = images[3];
startButton.img = images[4];
levelButton.img = images[6];
quitButton.img = images[12]
title.img = images[8];
splash.img = images[9];
bullet.img = images[10];
leftarm.img = images[17];
rightarm.img = images[18];
bossbot.img = images[23];
gameOver.img = images[20];
pauseMenu.img = images[21];
telegraph.img = images[27];
skull.img = images[29];
healthHUD.img = images[32];
mapOverlay.img = images[34];



function update(){
	//splashScreen
	if(screenState == 0){
		splashScreen();
	}
	//Title Screen
	else if (screenState == 1){
		startGame();
	}
	//Game Screen
	else if (screenState == 2){
		if (paused)
		{
			pMenu();
			return;
		}
		movePlayer();
		animatePlayer();
		bounds();
		checkCollision();
		fillMeter();
		movebullets();
		bulletCollision();
		enemyMovement();
		enemiesCollision();
		//moveBoss();
		//bossCollision();
		enemyAnimation();
	}
	
	Fadein();
	Fadeout();
	render();
	spawnSign();
}

function splashScreen(){
	if(splash.ctr >= splash.time){
		screenState = 1;
	}
	if(splash.ctr >= (splash.time - 50)){
		fadeOut = true;
	}
	splash.ctr ++;
}

function startGame(){	
	fadeIn = true;
	fadeOut = false;
	//goes down button if down pressed also stops if at last button
	if((downPressed || sPressed)&& bCtr < 2){
		//makes sure not to skip button
		downPressed = false;
		sPressed = false;
		bCtr ++;
	}
	//goes up button if up pressed also stops if at first button
	if((upPressed || wPressed) && bCtr > 0){
		//makes sure not to skip button
		upPressed = false;
		wPressed = false;
		bCtr --;
	}
	switch (bCtr >= 0)
	{
		case(bCtr == 0):
			startButton.img = images[5];
			levelButton.img = images[6];
			if(enterPressed){
				enterPressed = false;
				startHit();
			}
			break;
		case(bCtr == 1):
			startButton.img = images[4];
			levelButton.img = images[7];
			quitButton.img = images [12];
			break;
		case(bCtr == 2):
			quitButton.img = images[13];
			levelButton.img = images[6];
			if(enterPressed){
				window.close();
			}
			break;
	}
	
	
}

function Fadeout(){
	if(fadeOut == true){
		if(opaq>=0){
			surface.globalAlpha = opaq;
			opaq -= 0.02;
		}
	}
}
function Fadein(){
	if(fadeIn == true){
		if (opaq <= 1){
			surface.globalAlpha = opaq;
			opaq += 0.02;
		}
	}
}
function render(){
	//Splash Screen
	if(screenState == 0){
		surface.clearRect(0,0,canvas.width,canvas.height);
		surface.drawImage(splash.img, splash.x, splash.y, splash.width, splash.height);
	}
	//Start Menu
	if(screenState == 1){
		surface.clearRect(0,0,canvas.width,canvas.height);
		surface.drawImage(startButton.img, startButton.x, startButton.y, startButton.width, startButton.height);
		surface.drawImage(levelButton.img, levelButton.x, levelButton.y, levelButton.width, levelButton.height);
		surface.drawImage(quitButton.img, quitButton.x, quitButton.y, quitButton.width, quitButton.height);
		surface.drawImage(title.img, title.x, title.y, title.width, title.height);
	}
	//Game state
	if(screenState == 2){
		surface.clearRect(0,0,canvas.width,canvas.height);
		if(level == 0)
		surface.drawImage(map.img, map.x, map.y - 3200, map.width, map.height);
		for ( var i = 0; i < (mapArray[level][0].length); i++){
			for ( var j = 0; j < (mapArray[level].length); j++){
				surface.drawImage(mapArray[level][j][i].img, 32*mapArray[level][j][i].type, 0,32 ,32,mapArray[level][j][i].x, mapArray[level][j][i].y, 34,32);
			}
		}
		
		
		
		//if(bossCtr > 0){
			//surface.drawImage(bossbot.img, bossbot.x, bossbot.y, bossbot.width, bossbot.height);
		//}
		//surface.drawImage(leftarm.img, leftarm.x, leftarm.y, leftarm.width, leftarm.height);
		//surface.drawImage(rightarm.img, rightarm.x, rightarm.y, rightarm.width, rightarm.height);
		for(var e = 0; e < enemies.length; e++){
			if(enemies[e].type == 0){
				surface.drawImage(enemies[e].img, 218 * enemies[e].spriteCol , 161 * enemies[e].spriteRow,  218, 161,enemies[e].x, enemies[e].y, enemies[e].width, enemies[e].height);
			}
			if(enemies[e].type == 1){
				surface.drawImage(enemies[e].img, 81 * enemies[e].spriteCol , 69 * enemies[e].spriteRow,  81, 69,enemies[e].x, enemies[e].y, enemies[e].width, enemies[e].height);
			}
		}
	
if (respawn == false){
	switch(power){
		case 0:
			player.img = images[1];
			surface.drawImage(player.img,108*playerSprite, playFace, 108, 122,player.x, player.y, player.width, player.height);
			break;
		case 1:
			player.img = images[30];
			surface.drawImage(player.img,108*playerSprite, playFace, 108, 122,player.x, player.y, player.width, player.height);
			break;
		case 2:
			player.img = images[31];
			surface.drawImage(player.img,108*playerSprite, playFace, 108, 122,player.x, player.y, player.width, player.height);
			break;
		case 3:
			player.img = images[33];
			surface.drawImage(player.img,108*playerSprite, playFace, 108, 122,player.x, player.y, player.width, player.height);
			break;
	}
	
}
else {
        surface.drawImage(skull.img, canvas.width - 600, Dup, 200, 200);
		
		wPressed= aPressed = dPRessed= sPressed = false;
		Dup --;
}
		
		if (wPressed == 1)
    {
		if(teleCol == true){
			telegraph.img = images[28]
		}
		else{
			telegraph.img = images[27]
		}
        if (tpRight == true)
        {
			teleCollision();
			telegraph.x = player.x + player.width;
			telegraph.y = player.y;
           surface.drawImage(telegraph.img, 300, 0, 300, 64, telegraph.x, telegraph.y , teleDist, player.height);
        }
        else if (tpLeft == true)
        {
			teleCollision();
			telegraph.x = player.x - teleDist;
			telegraph.y = player.y;
			surface.drawImage(telegraph.img, 0, 0, 300, 64, telegraph.x , telegraph.y , teleDist, player.height);
        }
    }
		
		//lives
		surface.font = "20px Georgia";
		surface.fillText("Lives: " + lives.toString(), 850, 50);
		
		for (var i = 0; i < bulletArray.length; i++)
		{
			surface.drawImage(bullet.img, bulletArray[i].x, bulletArray[i].y, bulletArray[i].width, bulletArray[i].height);
		}
		if(gOver){
			goodGame();
		}
		if(level == 0)
		surface.drawImage(mapOverlay.img, mapOverlay.x, mapOverlay.y - 3200, mapOverlay.width, mapOverlay.height);
		surface.drawImage(bar.img, bar.x, bar.y, bar.width, bar.height);
		surface.drawImage(barHUD.img, barHUD.x, barHUD.y, barHUD.width, barHUD.height);
		surface.drawImage(healthHUD.img, 320*pShield, 0,320 ,320,healthHUD.x, healthHUD.y, healthHUD.width,healthHUD.height);
	}
}
function startHit(){
	shootBlock();
	screenState = 2;
	map.width = (mapArray[level][0].length * 32);
	map.height = (mapArray[level].length * 32);
	mapOverlay.width = map.width;
	mapOverlay.height = map.height;
	for(var q = 0; q < mapArray.length; q++){
		
		for ( var j = 0; j< (mapArray[level].length); j++)
		{
			for ( var i = 0; i< (mapArray[level][0].length); i++)
			{
			
				var tile = {};
				if(level == 0)
					tile.img = images[35];
				if(level == 1)
					tile.img = images[11];
				tile.x = i*32;  
				tile.y = j*32 - ((mapArray[level].length - 20)*32);
				switch(tile.x == i*32){
					
					case (mapArrayO[q][j][i] == 0):
						//AIR
						tile.type = 0;
						break;
					case(mapArrayO[q][j][i] == 1):
						//PLATFORM
						tile.type = 1;
						break;
					case(mapArrayO[q][j][i] == 2):
						//JUMP THROUGH BOT
						tile.type = 2;
						break;
					case(mapArrayO[q][j][i] == 3):
						//BREAKABLE BLOCK
						tile.type = 3;
						tile.hits = 1;
						break;
					case(mapArrayO[q][j][i] == 4):
						//BUTTON BLOCK
						tile.sideways = false;
						tile.type = 13;
						break;
					case(mapArrayO[q][j][i] == 5):
						//LEVEL UP
						tile.type = 7;
						break;
					case(mapArrayO[q][j][i] == 6):
						//NEXT LEVEL
						tile.type = 6;
						break;
					case(mapArrayO[q][j][i] == 7):
						//smallRat
						spawnSmallRat(tile.x ,tile.y,q);
						tile.type = 0;
						break;
					case(mapArrayO[q][j][i] == 8):
						//largeRat
						spawnLargeRat(tile.x ,tile.y, q);
						tile.type = 0;
						break;	
					case(mapArrayO[q][j][i] == 9):
						//enemeies reverse walking
						tile.type = 5;
						break;
					case(mapArrayO[q][j][i] == 10):
						//sign
						tile.type = 9;
						tile.sNum = sNumCtr;
						sNumCtr ++;
						break;
					case(mapArrayO[q][j][i] == 11):
						//shooting block left
						shootingBlockInMap = true;
						tile.type = 15;
						break;
					case(mapArrayO[q][j][i] == 12):
						//shooting block up
						shootingBlockInMap = true;
						tile.type = 16;
						break;
					case(mapArrayO[q][j][i] == 13):
						//shooting block right
						shootingBlockInMap = true;
						tile.type = 17;
						break;
					case(mapArrayO[q][j][i] == 14):
						//shooting block down
						shootingBlockInMap = true;
						tile.type = 18;
						break;
					case(mapArrayO[q][j][i] == 15):
						//Shield Potion
						tile.type = 19;
						break;
					case(mapArrayO[q][j][i] == 16):
						//Gravity swap
						tile.type = 20;
						break;
					case(mapArrayO[q][j][i] == 17):
						//Up floor
						tile.type = 21;
						break;
					case(mapArrayO[q][j][i] == 18):
						//BUTTON BLOCK sideways
						tile.sideways = true;
						tile.type = 13;
						break;
				}	
				mapArray[q][j][i] = tile; 
				
			}
		}
		
	}
	//var map = {img:null, x:0, y:mapArray[level][mapArray[level].length][0].y, width:(mapArray[level][0].length * 32), height:(mapArray[level].length * 32), xvel:0, yvel:0, oldX: 0, oldY: 0};
}

function movePlayer(){
	if(player.yvel == 3){
		player.onGround = true;
	}
	//move player right 
	if(dPressed){
		if(boundR <= canvas.width && player.x + player.width <= canvas.width){
			if(map.xvel < 0){
				player.xvel = -map.xvel;
			}
			player.xvel += movementSpeed;
			map.xvel = 0;
		}
		else if(boundL >= -32 && player.x >=0 && player.x <= canvas.width/2){
			if(map.xvel < 0){
				player.xvel = -map.xvel;
			}
			player.xvel += movementSpeed;
			map.xvel = 0;
		}
		else if(player.x + player.width <= canvas.width){
			if(player.xvel > 0){
				map.xvel = -player.xvel;
			}
			map.xvel -= movementSpeed;
			player.xvel = 0;
		}
		else{
			map.xvel = 0;
			player.xvel = 0;
		}
	}
	//move player left
	if(aPressed){
		if(boundR <= canvas.width && player.x >= canvas.width/2){
			if(map.xvel > 0){
				player.xvel = -map.xvel;
			}
			player.xvel -= movementSpeed;
			map.xvel = 0;
		}
		else if(boundL >= 0 && player.x >=0){
			if(map.xvel > 0){
				player.xvel = -map.xvel;
			}
			player.xvel -= movementSpeed;
			map.xvel = 0;
		
		}
		else if(player.x >= 0){
			if(player.xvel < 0){
				map.xvel = -player.xvel;
			}
				map.xvel += movementSpeed;
				player.xvel = 0;
		}
		else{
			map.xvel = 0;
			player.xvel = 0;
		}

	}
	//top
	if(player.y < 100)
	{
		map.yvel += 2.5
	}
	if(map.yvel < mapMaxY){
		map.yvel = 0;
	}
	mapMaxY = map.yvel;
	if(player.y > 450 && mapArray[level][(mapArray[level].length-1)][0].y >= canvas.height)
	{
		map.yvel -= 3.5
	}
	else if(player.y > 400 && mapArray[level][(mapArray[level].length-1)][0].y < canvas.height){
		map.yvel = 0
	}
	//jump 
	if(spacePressed && player.onGround && !invertGravity){
		player.yvel -= jumpPower;
		var audio = new Audio("jumpS.wav");
        audio.play();
		player.onGround = false;
		
	}
	if(spacePressed && player.onGround && invertGravity){
		player.yvel += jumpPower;
		var audio = new Audio("jumpS.wav");
         audio.play();
		player.onGround = false;
	}
	
	if (TP == true && tpRight == true && bar.width > 100 && teleCol == false){
		for ( var i = 0; i< (mapArray[level][0].length); i++)
			{
				for ( var j = 0; j< (mapArray[level].length); j++)
				{
					mapArray[level][j][i].x -= 300
					
				}
				
			}
			for(var p = 0; p < enemies.length ; p++){
					enemies[p].x -= 300;
				}
    bar.width -= 100;
	map.x -= 300
	mapOverlay.x -= 300;
	TP = false;
	tpRight = false;
	}
	else if (TP == true && tpLeft == true && bar.width > 100 && teleCol == false){
		for ( var i = 0; i< (mapArray[level][0].length); i++)
			{
				for ( var j = 0; j< (mapArray[level].length); j++)
				{
					mapArray[level][j][i].x += 300
				}
			}
			for(var p = 0; p < enemies.length ; p++){
					enemies[p].x += 300;
				}
    bar.width -= 100;
	TP = false;
	tpLeft = false
	map.x += 300
	mapOverlay.x += 300;
	}
	else {
		TP = false;
	}
	if(map.yvel < 2 && map.yvel > -2){
		map.yvel = 0;
		mapMaxY = 0;
	}
	
	//movement physics
	for ( var i = 0; i< (mapArray[level][0].length); i++)
	{
		for ( var j = 0; j< (mapArray[level].length); j++)
		{
			mapArray[level][j][i].x += map.xvel
			mapArray[level][j][i].y += map.yvel
		}
	}
	for(var q = 0; q < bulletArray.length; q++){
		bulletArray[q].x += map.xvel;
		bulletArray[q].y += map.yvel;
	}
	for(var p = 0; p < enemies.length; p++){
		enemies[p].x += map.xvel;
		enemies[p].y += map.yvel;
	}
	player.y += player.yvel;
	player.x += player.xvel;
	map.x += map.xvel;
	map.y += map.yvel;
	mapOverlay.y += map.yvel;
	mapOverlay.x += map.xvel;
	
	player.yvel *= 0.9;
	player.xvel *= 0.9;
	map.xvel *= 0.9;
	map.yvel *= 0.9;
}
function upFloor(){
	player.y -= floorHeight;
	for(var p = 0; p < enemies.length ; p++){
		//enemies[p].y -= floorHeight;
	}
	for(var b = 0; b < bulletArray.length ; b++){
		//bulletArray[b].y -= floorHeight;
	}
}
function animatePlayer()
{
	//Faces direction last pressed
	if(playerSprite != 0 && LorR == 2 && !dPressed)
		playerSprite = 0;
	if(playerSprite != 7 && LorR == 1 && !aPressed)
		playerSprite = 7
	//Animation
	if((aPressed || dPressed) && player.x > 0){
		spriteCtr++;
		//Right animation
		if(spriteCtr == framesPerSprite && dPressed){
			LorR = 2;
			spriteCtr = 0;
			playFace = 12;
			playerSprite++;
			if (playerSprite >= rightSprite)
				playerSprite = 0;
		}
		//Left animation
		if(spriteCtr == framesPerSprite && aPressed){
			LorR = 1;
			spriteCtr = 0;
			playFace = 154;
			playerSprite--;
			if (playerSprite <= leftSprite)
				playerSprite = 7;
		}
	}
}
//check if keys are pressed or released
window.addEventListener("keydown", onKeyDown);
window.addEventListener("keyup", onKeyUp);
//Function for pressing key down
function onKeyDown(event)
{
	switch (event.keyCode)
	{
		case 37: //left arrow
			leftPressed = true;
			if(bar.width > 26 && power >= 1 && respawn == false){
				shootLeft = true;
				bar.width -= 26
				var audio = new Audio("shoot.wav");
                audio.play();
				spawnBullet();
			}
			break;
		case 39: //right arrow
			rightPressed = true;
			if(bar.width > 26 && power >= 1 && respawn == false){
				shootRight = true;
				bar.width -= 26
				var audio = new Audio("shoot.wav");
                audio.play();
				spawnBullet();
			}
			break;
		case 38: //up arrow
			if (upPressed == false )
            {
            upPressed = true;
			shootUp = true;
            }
            break
		case 40://down arrow
			
			downPressed = true;
			shootDown = true;
			break;
		case 32: //spacebar
			if(respawn == false)
			spacePressed = true;
			break;
		case 13: // enter
			enterPressed = true; 
			break; 
		case 65://a
			if(respawn == false)
			aPressed = true;
			if(wPressed){
				tpLeft = true;
				tpRight = false;
			}
			break;
		case 68:// d
			if(respawn == false)
			dPressed = true;
			if(wPressed){
				tpRight = true;
				tpLeft = false;
			}
			break;
		case 87://w
		if (power == 2 && respawn == false)	
			wPressed = true;
			break;
		case 83://s
			if(respawn == false)
			sPressed = true;
			break;
		case 80://p
			paused = !paused
			break;
		
	} 
}
//function for releasing key
function onKeyUp(event)
{
	switch (event.keyCode)
	{
		case 37: //left arrow
			if (power == 1 && respawn == false)
			leftPressed = false;
			shootLeft = false;
			break;
		case 39: //right arrow
			if (power == 1 && respawn == false)
			rightPressed = false;
			shootRight = false;
			break;
		case 38:// up arrow
			upPressed = false;
			shootUp = false;
			break;
		case 32: //spacebar
			spacePressed = false;
			break;
		case 40: //down arrow
			downPressed = false;
			shootDown = false;;
			break;
		case 13: //enter
			enterPressed = false;
			break;
		case 65://a
			aPressed = false;
			break;
		case 68:// d
			dPressed = false;
			rightCol = false;
			break;
		case 87://w
		if (power == 2 && respawn == false)
			TP = true;
			wPressed = false;
			break;
		case 83://s
			sPressed = false;
			break;
	}
}