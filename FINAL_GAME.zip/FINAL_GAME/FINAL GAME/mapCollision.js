var leftCollision, rightCollision, topCollision, bottomCollision = false;
var rowCollided = 0;
var colCollided = 0;
var signCol = false;
var rightCol = leftCol = false;
var teleCol = false;
var invertGravity = false;
function checkCollision()
{
	if(player.onGround == false){
		if(!invertGravity)
			player.yvel += 3;
		if(invertGravity)
			player.yvel -= 3;
	}
	for ( var i = 0; i< (mapArray[level][0].length); i++)
	{
		for ( var j = 0; j< (mapArray[level].length) ; j++)
		{
			
			//EFFECTS PLAYER DEPENDING ON WHAT COLLISION HIT
			if(topCollision){
				if(mapArray[level][rowCollided][colCollided].type == 6){
					changeLevel();
					topCollision = false 
					continue
				}
				
				player.y = mapArray[level][rowCollided][colCollided].y + 32
				player.yvel = 0.5;
				if(invertGravity){
					player.onGround = true;
					inAir = false;
					if(player.yvel > 0){
						player.yvel = 0;
					}
				}
				
				if(mapArray[level][rowCollided][colCollided].type == 7){
					power ++;
					mapArray[level][rowCollided][colCollided].type = 0
				}
				topCollision = false
				
				
			}
			else if(!topCollision && invertGravity)
			{
				//player.onGround = false;
			}
			if(bottomCollision){
				if(mapArray[level][rowCollided][colCollided].type == 6){
					changeLevel();
					bottomCollision = false 
					continue
				}
					player.y = mapArray[level][rowCollided][colCollided].y - player.height
					
				if(!invertGravity){
					player.onGround = true;
					if(player.yvel > 0){
						player.yvel = 0;
					}
					inAir = false;
				}
				if(mapArray[level][rowCollided][colCollided].type == 7){
					power ++;
					mapArray[level][rowCollided][colCollided].type = 0
				}
				bottomCollision = false;
			}
			else if(!bottomCollision && !invertGravity)
			{
				player.onGround = false;
			}
			if(leftCollision){
				if(mapArray[level][rowCollided][colCollided].type == 6){
					changeLevel();
					leftCollision = false 
					continue
				}
				
				player.x = mapArray[level][rowCollided][colCollided].x + 33;
				map.xvel = 0;
				player.xvel = 0;
				
				if(mapArray[level][rowCollided][colCollided].type == 7){
					power ++;
					mapArray[level][rowCollided][colCollided].type = 0
				}
				leftCollision = false;
			}
			if(rightCollision){
				if(mapArray[level][rowCollided][colCollided].type == 6){
					changeLevel();
					rightCollision = false 
					continue
				}
				player.x = mapArray[level][rowCollided][colCollided].x - player.width - 1;
				player.xvel = 0;
				map.xvel = 0;
				
				if(mapArray[level][rowCollided][colCollided].type == 7){
					power ++;
					mapArray[level][rowCollided][colCollided].type = 0
				}
				rightCollision = false;
			}
			//CHECKS COLLISION
			//top
			 if(player.x + 4 < mapArray[level][j][i].x + 32 && player.x + player.width - 4 > mapArray[level][j][i].x){
                if(player.y < mapArray[level][j][i].y + 32 && player.y + 10 > mapArray[level][j][i].y + 12){
					//any block you cant go through 
					if(mapArray[level][j][i].type == 1  || mapArray[level][j][i].type == 6|| mapArray[level][j][i].type == 3 || mapArray[level][j][i].type ==  7|| mapArray[level][j][i].type ==  10 || mapArray[level][j][i].type ==  11 || mapArray[level][j][i].type ==  12||mapArray[level][j][i].type ==  15|| mapArray[level][j][i].type ==  16|| mapArray[level][j][i].type ==  17
					|| mapArray[level][j][i].type ==  18){
						rowCollided = j;
						colCollided = i;
						topCollision = true
						continue
					}
					if(mapArray[level][j][i].type == 9){
						signCol = true;
						signNumber(mapArray[level][j][i].sNum);
						continue;
					}
					if(mapArray[level][j][i].type == 19){
						shield();
						mapArray[level][j][i].type = 0;
					}
					if(mapArray[level][j][i].type == 20&& power == 3){
						invertGravity = !invertGravity;
						mapArray[level][j][i].type = 0;
						player.onGround = false
					}
					if(mapArray[level][j][i].type == 21){
						upFloor();
					}

				}
			}
			//bottom
			if(player.x + 4 < mapArray[level][j][i].x + 32 && player.x + player.width - 4 > mapArray[level][j][i].x){
                if((player.y + player.height > mapArray[level][j][i].y) && player.y + player.height - 15 < mapArray[level][j][i].y + 20){
					//any block you cant go through 
					if(mapArray[level][j][i].type == 1 || mapArray[level][j][i].type == 2 || mapArray[level][j][i].type == 6|| mapArray[level][j][i].type == 3 || mapArray[level][j][i].type ==  7|| mapArray[level][j][i].type ==  10 || mapArray[level][j][i].type ==  11 || mapArray[level][j][i].type ==  12||mapArray[level][j][i].type ==  15|| mapArray[level][j][i].type ==  16
					|| mapArray[level][j][i].type ==  17|| mapArray[level][j][i].type ==  18){
						rowCollided = j;
						colCollided = i;
						bottomCollision = true
						continue
					}
					if(mapArray[level][j][i].type == 9){
						signCol = true;
						signNumber(mapArray[level][j][i].sNum);
						continue;
					}if(mapArray[level][j][i].type == 19){
						shield();
						mapArray[level][j][i].type = 0;
					}
					if(mapArray[level][j][i].type == 20&& power == 3){
						invertGravity = !invertGravity;
						mapArray[level][j][i].type = 0;
						player.onGround = false

					}
					if(mapArray[level][j][i].type == 21){
						upFloor();
					}
					
					
				}
			}
			//RIGHT
			if(player.y + 4 < mapArray[level][j][i].y + 32 && player.y + player.height - 4 > mapArray[level][j][i].y){
                if(player.x + player.width > mapArray[level][j][i].x && player.x + player.width - 10 < mapArray[level][j][i].x + 20 ){
					//any block you cant go through 
					if(mapArray[level][j][i].type == 1 || mapArray[level][j][i].type == 6|| mapArray[level][j][i].type == 3 || mapArray[level][j][i].type ==  7 || mapArray[level][j][i].type ==  10 || mapArray[level][j][i].type ==  11 || mapArray[level][j][i].type ==  12||mapArray[level][j][i].type ==  15|| mapArray[level][j][i].type ==  16|| mapArray[level][j][i].type ==  17
					|| mapArray[level][j][i].type ==  18){
						rowCollided = j;
						colCollided = i;
						rightCollision = true
						continue;
					}
					if(mapArray[level][j][i].type == 9){
						signCol = true;
						signNumber(mapArray[level][j][i].sNum);
						continue;
					}
					if(mapArray[level][j][i].type == 19){
						shield();
						mapArray[level][j][i].type = 0;
					}
					if(mapArray[level][j][i].type == 20&& power == 3){
						invertGravity = !invertGravity;
						mapArray[level][j][i].type = 0;
						player.onGround = false

					}
					if(mapArray[level][j][i].type == 21){
						upFloor();
					}
				}
			}
			//LEFT
			if(player.y + 4 < mapArray[level][j][i].y + 32 && player.y + player.height - 4 > mapArray[level][j][i].y){
                if(player.x + 10 > mapArray[level][j][i].x + 12 && player.x < mapArray[level][j][i].x + 32){
					//any block you cant go through 
					if(mapArray[level][j][i].type == 1 || mapArray[level][j][i].type == 6|| mapArray[level][j][i].type == 3 || mapArray[level][j][i].type ==  7|| mapArray[level][j][i].type ==  10 || mapArray[level][j][i].type ==  11 || mapArray[level][j][i].type ==  12|| mapArray[level][j][i].type ==  15|| mapArray[level][j][i].type ==  16|| mapArray[level][j][i].type ==  17
					|| mapArray[level][j][i].type ==  18){
						rowCollided = j;
						colCollided = i;
						leftCollision = true;
						continue;
					}
					if(mapArray[level][j][i].type == 9){
						signCol = true;
						signNumber(mapArray[level][j][i].sNum);
						continue;
					}
					if(mapArray[level][j][i].type == 19){
						shield();
						mapArray[level][j][i].type = 0;
					}
					if(mapArray[level][j][i].type == 20 && power == 3){
						invertGravity = !invertGravity;
						mapArray[level][j][i].type = 0;
						player.onGround = false

					}
					if(mapArray[level][j][i].type == 21){
						upFloor();
					}
				}
			}
			
			
		}
	}
		
	
	
	if(player.y > mapArray[level][mapArray[level].length -1][0].y){
		death();
	}
}
var tCounter = 0;
function teleCollision(){
	for ( var i = 0; i< (mapArray[level][0].length); i++)
	{
		for ( var j = 0; j< (mapArray[level].length) ; j++)
		{
			if(telegraph.x < mapArray[level][j][i].x + 32 && telegraph.x + teleDist > mapArray[level][j][i].x && telegraph.y + player.height > mapArray[level][j][i].y && telegraph.y < mapArray[level][j][i].y + 32){
				if(mapArray[level][j][i].type == 1 || mapArray[level][j][i].type == 2 || mapArray[level][j][i].type == 6|| mapArray[level][j][i].type == 3){
						tCounter ++;
				}
			}
		}
	}
	if(tCounter > 0){
		teleCol = true;
	}
	else{
		teleCol = false;
	}
	tCounter = 0;
}