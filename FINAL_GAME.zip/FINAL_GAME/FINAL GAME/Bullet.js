const BULLETSPEED = 20;
var bulletArray = [];
var shootLeft = false;
var shootUp = shootDown = false;
bulletArray.shootLeft = false;
bulletArray.shootRight= false;
bulletArray.shootUp = false;
bulletArray.shootDown= false;
var buttonHit = false;
function spawnBullet()
{
	if(shootLeft){
		if(shootUp)
		{
			var bullet = {x:player.x+player.width/1.5, y:player.y+player.height/2,shootLeft:shootLeft, shootUp: true, shootDown: false, width: 8, height: 8, tile: false, hurtPlayer: false};
		}
		else if(shootDown)
		{
			var bullet = {x:player.x+player.width/1.5, y:player.y+player.height/2,shootLeft:shootLeft, shootUp: false, shootDown: true, width: 8, height: 8, tile: false, hurtPlayer: false};
		}
		else
		{
		var bullet = {x:player.x+player.width/1.5, y:player.y+player.height/2,shootLeft:shootLeft, shootUp: false, shootDown: false, width: 8, height: 8, tile: false, hurtPlayer: false};
		}
	}
	else if (shootRight)
	{
		if(shootUp)
		{
			var bullet = {x:player.x+player.width/1.5, y:player.y+player.height/2,shootLeft:shootLeft, shootUp: true, shootDown: false, width: 8, height: 8, tile: false, hurtPlayer: false};
		}
		else if(shootDown)
		{
			var bullet = {x:player.x+player.width/1.5, y:player.y+player.height/2,shootLeft:shootLeft, shootDown: true, shootUp: false, width: 8, height: 8, tile: false, hurtPlayer: false};
		}
		else
		{
		var bullet = {x:player.x+player.width/1.5, y:player.y+player.height/2,shootLeft:shootLeft, shootUp: false, shootDown: false, width: 8, height: 8, tile: false, hurtPlayer: false};
		}
	}
	
		bulletArray.push(bullet);
	
}
function spawnBulletTile(tileX, tileY){
	var x = tileX;
	var y = tileY;
	if(tileUp){
		var bullet = {x:(x + 16), y:y,shootLeft:false, shootUp: true, shootDown: false, width: 8, height: 8, tile: true, hurtPlayer: true};
		
		tileUp = false;
	}
	else if(tileDown){
		var bullet = {x:(x + 16), y:y,shootLeft:false, shootUp: false, shootDown: true, width: 8, height: 8, tile: true, hurtPlayer: true};
		
		tileDown = false;
	}
	else if(tileLeft){
		var bullet = {x:(x + 16), y:y,shootLeft:true, shootUp: false, shootDown: false, width: 8, height: 8, tile: true, hurtPlayer: true};
		
		tileLeft = false;
	}
	else if(tileRight){
		var bullet = {x:(x + 16), y:y,shootLeft:false, shootUp: false, shootDown: false, width: 8, height: 8, tile: true, hurtPlayer: true};
		
		tileRight = false;
	}
	bulletArray.push(bullet);
}

function movebullets()
{
	var i = 0;
	while (bulletArray[i] != undefined)
	{
		//bullet block up
		if(bulletArray[i].y > 0 && bulletArray[i].shootUp && bulletArray[i].tile){
			bulletArray[i++].y -= BULLETSPEED;
		}
		//bullet block left
		else if(bulletArray[i].x > 0 && bulletArray[i].shootLeft && bulletArray[i].tile){
			bulletArray[i++].x -= BULLETSPEED;
		}
		//bullet block down
		else if(bulletArray[i].y < canvas.height && bulletArray[i].shootDown && bulletArray[i].tile){
			bulletArray[i++].y += BULLETSPEED;
		}
		//bullet block right
		else if(bulletArray[i].x < canvas.width && !bulletArray[i].shootLeft && !bulletArray[i].shootDown && !bulletArray[i].shootUp && bulletArray[i].tile){
			bulletArray[i++].x += BULLETSPEED;
		}
		else if (bulletArray[i].x < canvas.width+5 && !bulletArray[i].shootLeft && !bulletArray[i].tile)
		{
			
			if(bulletArray[i].shootUp == true)
			{
				bulletArray[i].y -= BULLETSPEED * 0.3;
			}
			if(bulletArray[i].shootDown == true)
			{
				bulletArray[i].y += BULLETSPEED * 0.3;
			}
			bulletArray[i++].x += BULLETSPEED;
		}
		
		
		else if (bulletArray[i].x > -5 && bulletArray[i].shootLeft&& !bulletArray[i].tile)
		{
			
			if(bulletArray[i].shootUp == true)
			{
				bulletArray[i].y -= BULLETSPEED * 0.3;
			}
			if(bulletArray[i].shootDown == true)
			{
				bulletArray[i].y += BULLETSPEED * 0.3;
			}
			bulletArray[i++].x -= BULLETSPEED;
		}
		else{
			bulletArray.splice(i,1);
		}
	}
}
function bulletCollision(){
	for(var p = 0; p < bulletArray.length; p++){
		for(var q = 0; q < enemies.length;q++){
			if(bulletArray[p].x < enemies[q].x + enemies[q].width && bulletArray[p].x + bulletArray[p].width > enemies[q].x){
					if(bulletArray[p].y < enemies[q].y + enemies[q].width && bulletArray[p].y + bulletArray[p].height > enemies[q].y){
						if(!bulletArray[p].hurtPlayer){
						var audio = new Audio("enemy hit.wav");
						audio.play();
						bulletArray.splice(p,1);
						enemies.splice(q,1);
						return;
						}
					}
			}
		}
		
		
		
		
		for ( var i = 0; i< (mapArray[level][0].length); i++)
		{
			for ( var j = 0; j< (mapArray[level].length) ; j++)
			{
				if(bulletArray[p].x < mapArray[level][j][i].x + 32 && bulletArray[p].x + bulletArray[p].width > mapArray[level][j][i].x){
					if(bulletArray[p].y < mapArray[level][j][i].y + 32 && bulletArray[p].y + bulletArray[p].height > mapArray[level][j][i].y){
						if(mapArray[level][j][i].type == 1){
							if(level == 0){
							var audio = new Audio("collision.wav");
							audio.play();
							}
							bulletArray.splice(p,1);
							return;
						}
						//button block
						if(mapArray[level][j][i].type == 13 || mapArray[level][j][i].type == 14 ){
							if(mapArray[level][j][i].type == 13 && mapArray[level][j][i].sideways == false){
							
								mapArray[level][j][i].type = 14;
								mapArray[level][j+1][i].type = 0;
								mapArray[level][j+2][i].type = 0;
								mapArray[level][j+3][i].type = 0;
								
							}
							else if(mapArray[level][j][i].type == 14 && mapArray[level][j][i].sideways == false){

								mapArray[level][j][i].type = 13;
								mapArray[level][j+1][i].type = 1;
								mapArray[level][j+2][i].type = 1;
								mapArray[level][j+3][i].type = 1;
							}
							
							if(mapArray[level][j][i].type == 13 && mapArray[level][j][i].sideways == true){
								mapArray[level][j][i].type = 14;
								mapArray[level][j][i-1].type = 1;
								mapArray[level][j][i-2].type = 1;
								mapArray[level][j][i-3].type = 1;
								
							}
							else if(mapArray[level][j][i].type == 14 && mapArray[level][j][i].sideways == true){
								mapArray[level][j][i].type = 13;
								mapArray[level][j][i-1].type = 0;
								mapArray[level][j][i-2].type = 0;
								mapArray[level][j][i-3].type = 0;
							}
							if(level == 0){
							var audio = new Audio("collision.wav");
							audio.play();
							}
							bulletArray.splice(p,1);
							return;
						}
						if(mapArray[level][j][i].type == 3 || mapArray[level][j][i].type == 10 || mapArray[level][j][i].type == 11 || mapArray[level][j][i].type == 12){
							if(mapArray[level][j][i].hits > 2){
								mapArray[level][j][i].hits --;
								mapArray[level][j][i].type = 10;
								bulletArray.splice(p,1);
								return;
							}
							else if (mapArray[level][j][i].hits > 1){
								mapArray[level][j][i].hits --;
								mapArray[level][j][i].type = 11;
								bulletArray.splice(p,1);
								return
							}
							else if(mapArray[level][j][i].hits > 0){
								mapArray[level][j][i].hits --;
								mapArray[level][j][i].type = 12;
								bulletArray.splice(p,1);
								return
							}
							else{
								mapArray[level][j][i].type = 0;
								bulletArray.splice(p,1);
								return;
							}
							
						}
					}
				}
			} 
			
		}
		if(bulletArray[p].x < player.x + player.width && bulletArray[p].x + bulletArray[p].width > player.x){
			if(bulletArray[p].y < player.y + player.width && bulletArray[p].y + bulletArray[p].height > player.y){
				if(bulletArray[p].hurtPlayer){
					if(pShield <= 0){
					death();
					}
					else{
						pShield --;
					}
					bulletArray.splice(p,1);
				}
			}
		}
		
	}
}