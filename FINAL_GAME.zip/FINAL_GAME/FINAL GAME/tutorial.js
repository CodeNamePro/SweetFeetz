var signHUD = {img:null, x: canvas.width/4, y: 100, width: 500, height: 200}
signHUD.img = images[16]
var signNum
function spawnSign(sNum){
	if(signCol == true){
		surface.drawImage(signHUD.img, signHUD.x, signHUD.y, signHUD.width, signHUD.height);
		console.log(signNum);
		if(signNum == 9){
			surface.font = "20px Georgia";
			surface.fillText("**yawn**", signHUD.x + 20, signHUD.y + 50);
			surface.fillText("Wait, this looks like the lab!", signHUD.x + 20, signHUD.y + 70);
			surface.fillText("Why am I in the basement?", signHUD.x + 20, signHUD.y + 90);
			surface.fillText("What is this glowing thing in my chest!?", signHUD.x + 20, signHUD.y + 110);
			surface.fillText("WHAT'S GOING ON!?", signHUD.x + 20, signHUD.y + 130);
		}		
		if(signNum == 8){
			surface.font = "20px Georgia";
			surface.fillText("Use the 'A' and 'D' keys to move left and right", signHUD.x + 20, signHUD.y + 50);
		}
		if(signNum == 7){
			surface.font = "20px Georgia";
			surface.fillText("Hmm, my chest glows brighter the more I move.", signHUD.x + 20, signHUD.y + 50);
			surface.fillText("press the 'spacebar' to jump,", signHUD.x + 20, signHUD.y + 70);
			surface.fillText("and watch out for rats.", signHUD.x + 20, signHUD.y + 90);
		}
		if(signNum == 6){
			surface.font = "20px Georgia";
			surface.fillText("What happend to this place?", signHUD.x + 20, signHUD.y + 50);
			surface.fillText("It seems to be abandoned. hmm," , signHUD.x + 20, signHUD.y + 70);
			surface.fillText("I wonder if my colleagues are alright.", signHUD.x + 20, signHUD.y + 90);	
		}			
		if(signNum == 5){
			surface.font = "20px Georgia";
			surface.fillText("Darn it! the front door's locked.", signHUD.x + 20, signHUD.y + 70);
			surface.fillText("Guess I'll just use the bridge", signHUD.x + 20, signHUD.y + 90);
			surface.fillText("upstairs to building B. May aswell", signHUD.x + 20, signHUD.y + 110);
			surface.fillText("try to see what's going on anyway.", signHUD.x + 20, signHUD.y + 130);
		}			
		if(signNum == 4){
			surface.font = "20px Georgia";
			surface.fillText("OH AWESOME! We finally finished the", signHUD.x + 20, signHUD.y + 50);
			surface.fillText("'Kinetic Blaster'! I wonder how they", signHUD.x + 20, signHUD.y + 70);
			surface.fillText("solved the power supply issues.", signHUD.x + 20, signHUD.y + 90);
			surface.fillText("It's hard to find a human body that can", signHUD.x + 20, signHUD.y + 110);
			surface.fillText("hold enough energy to fuel this", signHUD.x + 20, signHUD.y + 130);
			surface.fillText("without passing out after 2 shots", signHUD.x + 20, signHUD.y + 150);		
		}			
		if(signNum == 3){
			surface.font = "20px Georgia";
			surface.fillText("Hmm, says here, it only shoots when", signHUD.x + 20, signHUD.y + 50);
			surface.fillText("you have enough energy to consume, and", signHUD.x + 20, signHUD.y + 70);
			surface.fillText("to use 'arrow keys'to shoot the direction", signHUD.x + 20, signHUD.y + 90);
			surface.fillText("that I want.", signHUD.x + 20, signHUD.y + 110);
			surface.fillText("Where are the arrow keys on this thing?", signHUD.x + 20, signHUD.y + 130);
		}
		if(signNum == 2){
			surface.font = "20px Georgia";
			surface.fillText("Dear H.R.,", signHUD.x + 20, signHUD.y + 50);
			surface.fillText("If only someone would shoot that gaudy", signHUD.x + 20, signHUD.y + 70);
			surface.fillText("statue on Philip's desk. Then I wouldn't", signHUD.x + 20, signHUD.y + 90);
			surface.fillText("want to blow it up everyday.", signHUD.x + 20, signHUD.y + 110);
			surface.fillText("I would too. If only it didn't feel like", signHUD.x + 20, signHUD.y + 130);
			surface.fillText("the boss is always watching us...", signHUD.x + 20, signHUD.y + 150);		
		}			
		if(signNum == 1){
			surface.font = "20px Georgia";
			surface.fillText("What's this? A 'KINETIC TELPORTER!?", signHUD.x + 20, signHUD.y + 50);
			surface.fillText("WHO WAS WORKING ON THIS!? AMAZING!", signHUD.x + 20, signHUD.y + 70);
			surface.fillText("I guess I should have guess there were", signHUD.x + 20, signHUD.y + 90);
			surface.fillText("top secret projects being done here.", signHUD.x + 20, signHUD.y + 110);
	
		}			
		if(signNum == 0){
			
			surface.font = "20px Georgia";
			surface.fillText("Says that it only shifts matter at light speed,", signHUD.x + 20, signHUD.y + 50);
			surface.fillText("is does not travel through it.", signHUD.x + 20, signHUD.y + 70);
			surface.fillText("hold 'W' to check destination, and release it", signHUD.x + 20, signHUD.y + 90);
			surface.fillText("when the path is clear.", signHUD.x + 20, signHUD.y + 110);
			surface.fillText("WARNING: Uses alot of physical energy.", signHUD.x + 20, signHUD.y + 130);	
		}			
		
		signCol = false;
	}
}
function signNumber(sNum){
	signNum = sNum;
}
/*
"**yawn**" 
"Wait, this looks like the lab!"
"Why am I in the basement?"
"What is this glowing thing in my chest!?"
"WHAT'S GOING ON!?"

"Use the 'A' and 'D' keys to move left and right"

"Hmm, my chest glows brighter the more I move."
"press the 'spacebar' to jump,"
"and watch out for rats."

"What happend to this place?"
"It seems to be abandoned. hmm," 
"I wonder if my colleagues are alright."

"Darn it! the front door's locked."
"Guess I'll just use the bridge"
"upstairs to building B. May aswell"
"try to see what's going on anyway."

"OH AWESOME! We finally finished the"
"'Kinetic Blaster'! I wonder how they"
"solved the power supply issues."
"It's hard to find a human body that can"
"hold enough energy to fuel this"
"without passing out after 2 shots"

"Hmm, says here, it only shoots when"
"you have enough energy to consume, and"
"to use 'arrow keys'to shoot the direction"
"that I want."
"Where are the arrow keys on this thing?"

"Dear H.R.,"
"If only someone would shoot that gaudy"
"statue on Philip's desk. Then I wouldn't"
"want to blow it up everyday."
"I would too. If only it didn't feel like"
"the boss is always watching us..."

"What's this? A 'KINETIC TELPORTER!?"
"WHO WAS WORKING ON THIS!? AMAZING!"
"I guess I shoul have known there were"
"top secret projects being done here."

"Says that it only shifts matter at light speed,"
"is does not travel through it."
"hold 'W' to check destination, and release it"
"when the path is clear."
"WARNING: Uses alot of physical energy."


*/

