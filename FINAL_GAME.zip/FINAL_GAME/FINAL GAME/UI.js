var bCounter = 0;

function goodGame()
{
	surface.clearRect(0,0,canvas.width,canvas.height);
	surface.drawImage (gameOver.img, gameOver.x, gameOver.y, gameOver.width, gameOver.height);
	
	
	
	if((upPressed || wPressed) && bCounter > 0){
		
		//makes sure not to skip button
		upPressed = false;
		wPressed = false;
		bCounter --;
	}
	if((downPressed || sPressed) && bCounter < 1){
		
		//makes sure not to skip button
		downPressed = false;
		sPressed = false;
		bCounter ++;
		
	}
	switch (bCounter >= 0)
	{
		case(bCounter == 0):
			surface.strokeStyle="red";
			surface.strokeRect(349,310,313,55);

			
			
			if(enterPressed){
				enterPressed = false;
				lives = 6;
				death();
				gOver = false;
				respawn = false;
			}
			break;
			
		case(bCounter == 1):
			surface.strokeStyle="red";
			surface.strokeRect(349,418,313,55);
			
			if(enterPressed){
				enterPressed = false;
				window.close();
				}
			break;
	}
}
var pCounter = 0;
function pMenu()
{
	surface.drawImage (pauseMenu.img, pauseMenu.x, pauseMenu.y, pauseMenu.width, pauseMenu.height);
	
	

	if((upPressed || wPressed) && pCounter > 0){
		
		//makes sure not to skip button
		upPressed = false;
		wPressed = false;
		pCounter --;
	}
	if((downPressed || sPressed) && pCounter < 2){
		
		//makes sure not to skip button
		downPressed = false;
		sPressed = false;
		pCounter ++;
		
	}
	switch (pCounter >= 0)
	{
		case(pCounter == 0):
			surface.strokeStyle="red";
			surface.strokeRect(335,262,313,55);

			
			
			if(enterPressed){
				paused = false;
				enterPressed = false;
				
			}
			break;
			
		case(pCounter == 1):
			surface.strokeStyle="red";
			surface.strokeRect(335,340,313,55);
			
			if(enterPressed){
				screenState = 1;
				enterPressed = false;
				paused = false;
				enemies.splice(1,enemies.length-1)
				
				}
			break;
		case(pCounter == 2):
			surface.strokeStyle="red";
			surface.strokeRect(335,426,313,55);
			
			if(enterPressed){
				
				enterPressed = false;
				lives ++;
				paused = false;
				death();
				
				}
			break;
	}

}
	
