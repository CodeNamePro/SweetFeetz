var lives = 5;
var gOver = false;
var pShield = 0;
function death(){
	lives --;
	if(lives > 0){
		mapArray.x = player.xvel = player.yvel = map.xvel = map.x = map.yvel = map.y = mapOverlay.x = mapOverlay.y = 0;
		for ( var j = 0; j< (mapArray[level].length); j++)
		{
			for ( var i = 0; i< (mapArray[level][0].length); i++)
			{
				mapArray[level][j][i].x = i*32;  
				mapArray[level][j][i].y = (j*32 + (20-(mapArray[level].length))*32); 
				if(mapArrayO[level][j][i] == 15){
					mapArray[level][j][i].type = 19;
				}
				if(mapArrayO[level][j][i] == 15){
					mapArray[level][j][i].type = 19;
				}
				if(mapArrayO[level][j][i] == 3){
					mapArray[level][j][i].type = 3;
					mapArray[level][j][i].hits = 1;
				}
			}
		}
		for(var p = 0; p < enemies.length; p++){
			if(enemies[p].level == level){
					enemies[p].x = enemies[p].origX;
					if(enemies[p].movement < 0)
						enemies[p].movement = -enemies[p].movement;
					enemies[p].y = enemies[p].origY;
			}
		}
		bulletArray.splice(1,bulletArray.length-1);

		player.x = 200;
		player.y = canvas.height-132;
		bar.width = 0;
		respawn = false;
		Dup = canvas.height - 300;
		pShield = 0;
		invertGravity = false;
		bounds();
	}
	else{
		gg();
	}
}
function gg(){
	gOver = true;
}
function shield(){
	if(pShield < 4){
		pShield ++;
		shieldPickup = false;
	}
}