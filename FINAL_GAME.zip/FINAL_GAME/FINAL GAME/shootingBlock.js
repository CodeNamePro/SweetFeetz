var tileLeft = tileRight = tileDown = tileUp = false;

function shootBlock(){
	if(shootingBlockInMap){
	for ( var j = 0; j< (mapArray[level].length); j++){
			for ( var i = 0; i< (mapArray[level][0].length); i++){
				
				if(mapArray[level][j][i].type == 15){
					tileLeft = true;
					spawnBulletTile(mapArray[level][j][i].x, mapArray[level][j][i].y);
				}
				if(mapArray[level][j][i].type == 16){
					tileUp = true;
					spawnBulletTile(mapArray[level][j][i].x, mapArray[level][j][i].y);
				}
				if(mapArray[level][j][i].type == 17){
					tileRight = true;
					spawnBulletTile(mapArray[level][j][i].x, mapArray[level][j][i].y);
				}
				if(mapArray[level][j][i].type == 18){
					tileDown = true;
					spawnBulletTile(mapArray[level][j][i].x, mapArray[level][j][i].y);
				}
			}
		}
	setTimeout(shootBlock , 2000);
	}
}