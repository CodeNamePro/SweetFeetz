var enemyCtr = 0;
function spawnSmallRat(startX, startY, sLevel){
	var smallRat = {img:null, x:10000, y:10000 + 17, width: 32, height: 32, movement: 2, edgeHit: false, origX:startX, origY:startY, type: 0, level: sLevel, spriteCol: 0, spriteRow: 0}
	smallRat.img = images[14];
	if(smallRat.level == level){
		smallRat.x = startX ;
		smallRat.y = startY;
		
	}
	enemies[enemyCtr] = smallRat;
	enemyCtr++;
}
function spawnLargeRat(startX, startY, sLevel){
	var largeRat = {img:null, x:10000, y:10000, width: 192, height: 192, movement: 4, edgeHit: false, origX:startX, origY:startY, type: 1, level: sLevel, spriteCol: 0, spriteRow: 0}
	largeRat.img = images[15];
	if(largeRat.level == level){
		largeRat.x= startX;
		largeRat.y= startY;
		
	}
	enemies[enemyCtr] = largeRat;
	enemyCtr++;
	
}

function enemyMovement(){
	var rightHit = leftHit = false;
	for ( var i = 0; i< (mapArray[level][0].length); i++)
	{
		for ( var j = 0; j< (mapArray[level].length) ; j++)
		{
			for(var p = 0; p < enemies.length ; p++){
				//left
				if(enemies[p].y + 4 < mapArray[level][j][i].y + 32 && enemies[p].y + enemies[p].height - 4 > mapArray[level][j][i].y){
					if(enemies[p].x + 10 > mapArray[level][j][i].x + 12 && enemies[p].x < mapArray[level][j][i].x + 32){
						if(mapArray[level][j][i].type == 1 || mapArray[level][j][i].type == 6|| mapArray[level][j][i].type == 3 || mapArray[level][j][i].type ==  7|| mapArray[level][j][i].type ==  10 || mapArray[level][j][i].type ==  11 || mapArray[level][j][i].type ==  12|| mapArray[level][j][i].type ==  15|| mapArray[level][j][i].type ==  16|| mapArray[level][j][i].type ==  17|| mapArray[level][j][i].type ==  18|| mapArray[level][j][i].type ==  5){
							enemies[p].edgeHit = true;
						}
					}
				}
				//right
				if(enemies[p].y + 4 < mapArray[level][j][i].y + 32 && enemies[p].y + enemies[p].height - 4 > mapArray[level][j][i].y){
					if(enemies[p].x + enemies[p].width > mapArray[level][j][i].x && enemies[p].x + enemies[p].width - 10 < mapArray[level][j][i].x + 20 ){
						if(mapArray[level][j][i].type == 1 || mapArray[level][j][i].type == 6|| mapArray[level][j][i].type == 3 || mapArray[level][j][i].type ==  7|| mapArray[level][j][i].type ==  10 || mapArray[level][j][i].type ==  11 || mapArray[level][j][i].type ==  12|| mapArray[level][j][i].type ==  15|| mapArray[level][j][i].type ==  16|| mapArray[level][j][i].type ==  17|| mapArray[level][j][i].type ==  18|| mapArray[level][j][i].type ==  5){
							enemies[p].edgeHit = true;
						}
					}
				}
			}
		}
		
	}
	for(var p = 0; p < enemies.length ; p++){
		
		if(enemies[p].edgeHit == true){
			enemies[p].movement = -enemies[p].movement;
			enemies[p].edgeHit = false;
		}
		enemies[p].x += enemies[p].movement;
	}
}
function enemiesCollision(){
if (respawn == false)
	for(var p = 0; p < enemies.length ; p++){
		if(player.x < enemies[p].x + enemies[p].width && player.x + player.width > enemies[p].x && player.y + player.height > enemies[p].y && player.y < enemies[p].y + enemies[p].height){
			respawn = true;
			setTimeout(death, 2000)
			var audio = new Audio("death.wav");
            audio.play();
		}
	}
}
var bEnemyCtr = 4;
var enemySCounter = 10;
function enemyAnimation(){
	enemySCounter ++;
	bEnemyCtr ++;
	if(enemySCounter > 2){
		for(var p = 0; p < enemies.length ; p++){
			
			//small enemy animation
			if(enemies[p].type == 0){
				
				enemies[p].spriteCol ++;
				if(enemies[p].spriteCol > 3){
					enemies[p].spriteCol = 0;
				}
				//right
				if(enemies[p].movement > 0){
						enemies[p].spriteRow = 1;
				}
				//left
				else if(enemies[p].movement < 0){
					enemies[p].spriteRow = 0;
				}
			}
			//Large enemy animation
			if(enemies[p].type == 1){
				if(bEnemyCtr > 4){
					enemies[p].spriteCol ++;
					if(enemies[p].spriteCol > 3 && enemies[p].movement < 0){
						enemies[p].spriteCol = 0;
					}
					else if(enemies[p].spriteCol > 4 && enemies[p].movement > 0){
						enemies[p].spriteCol = 1;
					}
				}
				//right
				if(enemies[p].movement > 0){
						enemies[p].spriteRow = 0;
				}
				//left
				else if(enemies[p].movement < 0){
					enemies[p].spriteRow = 1;
				}
			}
			
		}
		enemySCounter = 0;
		if(bEnemyCtr > 4){
			bEnemyCtr = 0;
		}
	}
}
