const BULLETSPEED = 15;
var bulletArray = [];
bulletSize = 4; //number of pixels bullet is
var enemyHit
bulletArray.shootLeft = false;
bulletArray.shootRight= false;
function spawnBullet()
{
	if(shootLeft){
		var bullet = {x:player.x+player.width/1.5, y:player.y+player.height/2,shootLeft:shootLeft};
	}
	else if (!shootLeft){
		var bullet = {x:player.x+player.width/1.5, y:player.y+player.height/2,shootLeft:shootLeft};
	}
		bulletArray.push(bullet);
	
}

function movebullets()
{
	var i = 0;
	while (bulletArray[i] != undefined)
	{
		if (bulletArray[i].x < canvas.width+5 && !bulletArray[i].shootLeft){
			bulletArray[i++].x += BULLETSPEED;
	}
		else if (bulletArray[i].x > -5 && bulletArray[i].shootLeft)
			bulletArray[i++].x -= BULLETSPEED;
		else
			bulletArray.splice(i,1);
	}
}
function bulletCollision(){
	for(var i = 0; i < bulletArray.length; i++){
		if (bulletArray[i].x > enemy.x + enemy.width && bulletArray[i].x + bulletSize > enemy.x && bulletArray[i].y < enemy.y + enemy.height && bulletArray[i].y + 1 > enemy.y ){
			enemyHit = true;
			bulletArray.splice(i,1);
			enemy.x = -1000;
		}

	}
	if(enemyHit){
		enemy.alive = false;
	}
}