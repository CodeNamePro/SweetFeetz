

var hitRight = false;
function moveEnemy()
{

	if(enemy.ctr <= enemy.limit && !hitRight){
		enemy.x += 4
		enemy.ctr++
		if(enemy.ctr == enemy.limit){
			hitRight = true;
		}
	}
	else if(hitRight && enemy.ctr >= 0){
		enemy.x -= 4
		enemy.ctr--
		if(enemy.ctr == 0){
			hitRight = false;
		}
	}
	
	
	
}
function enemyCollision(){
	//with player
	if(player.x < enemy.x + enemy.width && player.x + player.width > enemy.x && player.y + player.height > enemy.y && player.y < enemy.y + enemy.height){
		death();
	}
	
}