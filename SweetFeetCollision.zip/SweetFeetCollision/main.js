/*
	To Do
	- map velocity movement
	- more platforms
	- enemy of some sort you have to jump over
	- moving platforms that move up and down or something 
	
*/
var canvas = document.querySelector("canvas"); //Create canvas 
canvas.width = 1000; //set canvas width
canvas.height = 640; // set canvas height
var surface = canvas.getContext("2d");

//movement variables
var leftPressed, rightPressed, upPressed, spacePressed = false;
//check if keys are pressed or released
window.addEventListener("keydown", onKeyDown);
window.addEventListener("keyup", onKeyUp);
//player variables
var player = {img:null, x: 100, y:400, jumping:false, xvel:0, yvel:0, onGround:false, width:64, height:64};
//map variables
var map = {img:null, x:0, y:0, xvel:0, yvel: 0, width:2000, height:canvas.height};
//Animation variables
var LorR = 0;
var spriteCtr = 0; 
var playerSprite = 0;
var leftSprite = 5;
var rightSprite = 4;
var framesPerSprite = 4;
//player speed
var pSpeed = 5;
//move counter
var moveCtr = 0;
var jumpCost = 50;
//max fall speed
var maxFall = 15;
//image variables
var images = [];
var imgStr = ["player","map","platf","bar","barHUD"];
//platform variables
var plat1 = {img:null, x: 0, y:500, width:400, height:64};
var plat2 = {img:null, x:300, y:400, width:300, height: 64};
//bar variables
var bar ={img:null, x:150, y:canvas.height-50, width:0, height:20};
var barHUD = {img:null, x:bar.x-2, y:bar.y-2, width:254, height:24};
startGame();

function startGame(){
	for (var i = 0; i < imgStr.length; i++)
	{
		images[i] = new Image();
		images[i].src = imgStr[i]+".png";
	}
	player.img = images[0];
	map.img = images[1]
	plat1.img = images[2];
	plat2.img = images [2];
	bar.img = images[3];
	barHUD.img = images[4]
	//start update timer
	uInt = setInterval(update, 33.34);
}

function update()
{
	checkCollision();
	movement();
	movementMap();
	playerAnimation();
	fillMeter();
	render();
	
	

}
function onKeyDown(event)
{
	switch (event.keyCode)
	{
		case 37: //left arrow
			leftPressed = true;
			break;
		case 39: //right arrow
			rightPressed = true;
			break;
		case 38: //up arrow
			upPressed = true;
			break;
		case 32: // spacebar
			spacePressed = true;
			break;
	} 
}

function onKeyUp(event)
{
	switch (event.keyCode)
	{
		case 37: //left arrow
			leftPressed = false;
			break;
		case 39: //right arrow
			rightPressed = false;
			break;
		case 38:// up arrow
			upPressed = false;
			break;
		case 32: //spacebar
			spacePressed = false;
			break;
	}
}
function movement(){
	if(spacePressed && !player.jumping && bar.width >= jumpCost){
		player.yvel -= 40;
		player.jumping = true;
		bar.width -= jumpCost;
	}
	if(player.onGround && !spacePressed){
		player.jumping = false;
	}
	if(leftPressed){
		if(moveCtr < 12){
			player.xvel -= 0.5;
			moveCtr ++;
		}
		else if (moveCtr <= 32){
			player.xvel -= 1;
			moveCtr++;
		}
		else if(moveCtr >= 33){
			player.xvel -= 1.2;
		}
	}
	else if(!leftPressed && moveCtr > 0){
		moveCtr = 0;
	}
	if(rightPressed){
		if(moveCtr >= -12){
			player.xvel += 0.5;
			moveCtr --;
		}
		else if (moveCtr >= -32){
			player.xvel += 1;
			moveCtr--;
		}
		else if(moveCtr <= -33){
			player.xvel += 1.2;
		}
	}
	else if (!rightPressed && moveCtr < 0){
		moveCtr = 0;
	}
	player.x += player.xvel;
	player.xvel *= 0.83;
	player.y += player.yvel;
	player.yvel *= 0.9;
}
function movementMap(){
	plat1.x = map.x + plat1.x;
}

function playerAnimation(){
	//Faces direction last pressed
	if(playerSprite != 0 && LorR == 2 && !rightPressed)
		playerSprite = 0;
	if(playerSprite != 7 && LorR == 1 && !leftPressed)
		playerSprite = 7
	//Animation
	if((rightPressed || leftPressed))
	{	
		spriteCtr++;
		//Right animation
		if (spriteCtr == framesPerSprite && rightPressed)
		{
			LorR = 2;
			spriteCtr = 0;
			playerSprite++;
			if (playerSprite >= rightSprite)
				playerSprite = 0;
		}
		//Left Animation
		if (spriteCtr == framesPerSprite && leftPressed)
		{
			LorR = 1;
			spriteCtr = 0;
			playerSprite--;
			if (playerSprite <= leftSprite)
				playerSprite = 7;
		}
	}
}
function render(){
	surface.clearRect(0,0,canvas.width,canvas.height);
	surface.drawImage(map.img, map.x, map.y, map.width, map.height);
	surface.drawImage(plat1.img, plat1.x, plat1.y, plat1.width, plat1.height);
	surface.drawImage(plat2.img, plat2.x, plat2.y, plat2.width, plat2.height);
	surface.drawImage(player.img,64*playerSprite, 0, 64, 64,player.x, player.y, player.width, player.height);
	surface.drawImage(bar.img, bar.x, bar.y, bar.width, bar.height);
	surface.drawImage(barHUD.img, barHUD.x, barHUD.y, barHUD.width, barHUD.height);
	
}
function checkCollision(){
	//platform 1
	if(((player.x >= plat1.x && player.x <= (plat1.x + plat1.width)) || ((player.x + player.width) >= plat1.x && (player.x + player.width) <= (plat1.x + plat1.width)))
		&& (player.y + player.height) >= plat1.y  && (player.y + player.height) <= (plat1.y + plat1.height)){
			if((player.y + player.height) <= (plat1.y + 24))
				player.yvel = 0;
			if((player.y - player.height) > plat1.y +20){
				player.y = plat1.y -player.height;
			}
			player.onGround = true;
			
	}
	//platform 2
	else if(((player.x >= plat2.x && player.x <= (plat2.x + plat2.width)) || ((player.x + player.width) >= plat2.x && (player.x + player.width) <= (plat2.x + plat2.width)))
		&& (player.y + player.height) >= plat2.y  && (player.y + player.height) <= (plat2.y + plat2.height)){
			if((player.y + player.height) <= (plat2.y + 24))
				player.yvel = 0;
			if((player.y - player.height) > plat2.y){
				player.y = plat2.y - player.height;
			}
			player.onGround = true;
			
			
	}
	else{
		player.onGround = false;
	}
	
	if(!player.onGround){
		if(player.yvel < maxFall)
			player.yvel += 3;
	}
	else{
	}
}
function fillMeter()
{
	if (player.xvel >= 0.5 || player.xvel <= -0.5)
	{
		if(bar.width <= 250){
			bar.width += 1;
		}
		//oldMPos = map.x;
	}
	else
	{
		if(bar.width != 0)
		bar.width -= 1;
	}
}