var canvas = document.querySelector("canvas"); //Create canvas 
canvas.width = 1000; //set canvas width
canvas.height = 640; // set canvas height
var surface = canvas.getContext("2d");

var images = [];
var imgStr = ["splash","main","settings","character","loading","guns","item","pause","gameover","map","mission"];
for(var v = 0; v < imgStr.length; v++){
	images[v] = new Image();
	images[v].src = imgStr[v] + ".png";
}

var splash = {img:null, x:0, y:0, width: canvas.width, height:canvas.height};
var main = {img:null, x:0, y:0, width: canvas.width, height:canvas.height};
var settings = {img:null, x:0, y:0, width: canvas.width, height:canvas.height};
var character = {img:null, x:0, y:0, width: canvas.width, height:canvas.height};
var loading = {img:null, x:0, y:0, width: canvas.width, height:canvas.height};
var guns = {img:null, x:0, y:0, width: canvas.width, height:canvas.height};
var item = {img:null, x:0, y:0, width: canvas.width, height:canvas.height};
var pause = {img:null, x:0, y:0, width: canvas.width, height:canvas.height};
var gameover = {img:null, x:0, y:0, width: canvas.width, height:canvas.height};
var map = {img:null, x:0, y:0, width: canvas.width, height:canvas.height};
var mission = {img:null, x:0, y:0, width: canvas.width, height:canvas.height};


splash.img = images[0];
main.img = images[1];
settings.img = images[2];
character.img = images[3];
loading.img = images[4];
guns.img = images[5];
item.img = images[6];
pause.img = images[7];
gameover.img = images[8];
map.img = images[9];
mission.img = images[10];


function onKeyDown(event)
{
	switch (event.keyCode)
	{
		case 37: //left arrow
			leftPressed = true;
			break;
		case 39: //right arrow
			rightPressed = true;
			break;
		case 38: //up arrow
			leftPressed = true;
			break;
		case 40: //down arrow
			rightPressed = true;
			break;
		case 13: //enter
			enterPressed = true;
			break;
	}
}

function onKeyUp(event)
{
	switch (event.keyCode)
	{
		case 37: //left arrow
			leftPressed = false;
			break;
		case 39: //right arrow
			rightPressed = false;
			break;
		case 38: //up arrow
			leftPressed = false;
			break;
		case 40: //down arrow
			rightPressed = false;
			break;
		case 13: //enter
			enterPressed = false;
			break;
	}
}
